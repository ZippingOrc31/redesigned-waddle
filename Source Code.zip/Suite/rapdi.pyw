import tkinter as tk
from datetime import datetime
from tkinter import simpledialog, messagebox, filedialog
import threading
import time
import pynput
import sys
import ctypes
import os
import glob
import configparser
import json
import zipfile

from pynput.keyboard import Listener as KeyListener, Key
from pynput.mouse import Listener as MouseListener, Button
from pynput.keyboard import Controller as KeyboardController

import sounddevice as sd
import speech_recognition as sr


# ================================================================
# WINDOWS CONSOLE
# ================================================================

if sys.platform == "win32":
    try:
        ctypes.windll.user32.ShowWindow(
            ctypes.windll.kernel32.GetConsoleWindow(), 0
        )
    except Exception:
        pass


# ================================================================
# WINDOWS MOUSE INPUT
# ================================================================

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", ctypes.c_long),
        ("dy", ctypes.c_long),
        ("mouseData", ctypes.c_ulong),
        ("dwFlags", ctypes.c_ulong),
        ("time", ctypes.c_ulong),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
    ]


class INPUT(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_ulong),
        ("mi", MOUSEINPUT),
    ]


SendInput = (
    ctypes.windll.user32.SendInput
    if sys.platform == "win32"
    else None
)

MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_ABSOLUTE = 0x8000
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_WHEEL = 0x0800


def send_mouse_move(dx, dy):
    if SendInput is None:
        return

    inp = INPUT()
    inp.type = 0
    inp.mi = MOUSEINPUT(
        dx,
        dy,
        0,
        MOUSEEVENTF_MOVE,
        0,
        None
    )

    SendInput(
        1,
        ctypes.byref(inp),
        ctypes.sizeof(inp)
    )


def send_mouse_move_absolute(x, y):
    if SendInput is None:
        return

    user32 = ctypes.windll.user32

    w = max(user32.GetSystemMetrics(0), 2)
    h = max(user32.GetSystemMetrics(1), 2)

    ax = int(x * 65535 / (w - 1))
    ay = int(y * 65535 / (h - 1))

    inp = INPUT()
    inp.type = 0
    inp.mi = MOUSEINPUT(
        ax,
        ay,
        0,
        MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE,
        0,
        None
    )

    SendInput(
        1,
        ctypes.byref(inp),
        ctypes.sizeof(inp)
    )


def send_mouse_click(button, down):
    if SendInput is None:
        return

    inp = INPUT()
    inp.type = 0

    if button == "left":
        inp.mi.dwFlags = (
            MOUSEEVENTF_LEFTDOWN
            if down
            else MOUSEEVENTF_LEFTUP
        )

    elif button == "right":
        inp.mi.dwFlags = (
            MOUSEEVENTF_RIGHTDOWN
            if down
            else MOUSEEVENTF_RIGHTUP
        )

    SendInput(
        1,
        ctypes.byref(inp),
        ctypes.sizeof(inp)
    )


def send_mouse_scroll(amount):
    if SendInput is None:
        return

    inp = INPUT()
    inp.type = 0

    inp.mi = MOUSEINPUT(
        0,
        0,
        amount,
        MOUSEEVENTF_WHEEL,
        0,
        None
    )

    SendInput(
        1,
        ctypes.byref(inp),
        ctypes.sizeof(inp)
    )


# ================================================================
# MACRO RECORDER
# ================================================================

class MacroRecorder(tk.Frame):

    def __init__(self, parent):
        super().__init__(parent, bg="black")

        self.parent = parent

        self.recording = False
        self.playing_back = False

        self.events = []
        self.start_time = 0

        self.playback_speed = 1.0
        self.loop_count = 1
        self.loop_infinite = False

        self.record_mode = tk.StringVar(value="relative")

        self.keyboard = KeyboardController()

        self.macro_folder = "macros"
        os.makedirs(self.macro_folder, exist_ok=True)

        self.config_file = "hotkeys.cfg"

        self.record_hotkey = None
        self.play_hotkey = None

        self.load_hotkeys()

        self.mod_ctrl = False
        self.mod_shift = False
        self.mod_alt = False
        self.mod_cmd = False

        self.record_mod_ctrl = False
        self.record_mod_shift = False
        self.record_mod_alt = False
        self.record_mod_cmd = False

        self._handled_global_hotkeys = set()

        # Tracks keys actually pressed by playback.
        # This is the important cleanup protection against
        # modifiers/keys remaining stuck after playback.
        self.playback_pressed_keys = set()
        self.playback_modifier_state = set()

        self.voice_phrase = tk.StringVar(value="clip that")
        self.voice_macro = None
        self.voice_running = False

        self.voice_bindings_file = os.path.join(
            self.macro_folder,
            "voice_bindings.json"
        )
        self.schedule_bindings_file=os.path.join(
            self.macro_folder,
            "macro_schedules.json"
        )

        self.schedule_bindings=self.load_schedule_bindings()

        self.scheduler_running=True
        self.scheduler_last_trigger={}

        threading.Thread(
            target=self.scheduler_loop,
            daemon=True
        ).start()

        self.voice_bindings = self.load_voice_bindings()

        self.voice_device = tk.StringVar()
        self.audio_buffer = b""

        self.recognizer = sr.Recognizer()

        self.keymap = self.load_keymap()

        # --------------------------------------------------------
        # MAIN UI
        # --------------------------------------------------------

        main_frame = tk.Frame(self, bg="black")
        main_frame.pack(fill="both", expand=True)

        left_frame = tk.Frame(main_frame, bg="black")
        left_frame.pack(fill="both", expand=True)

        tk.Label(
            left_frame,
            text="Zippys Macro Suite",
            fg="white",
            bg="black"
        ).pack(pady=5)

        # --------------------------------------------------------
        # SPEED / LOOP
        # --------------------------------------------------------

        speed_frame = tk.Frame(left_frame, bg="black")
        speed_frame.pack(pady=3)

        tk.Label(
            speed_frame,
            text="Speed:",
            fg="white",
            bg="black"
        ).grid(row=0, column=0, padx=5)

        self.speed_var = tk.StringVar(value="1.0x")

        tk.OptionMenu(
            speed_frame,
            self.speed_var,
            "0.1x",
            "0.25x",
            "0.5x",
            "1.0x",
            "1.5x",
            "2.0x",
            "5.0x",
            "10.0x"
        ).grid(row=0, column=1, padx=5)

        tk.Label(
            speed_frame,
            text="Loop:",
            fg="white",
            bg="black"
        ).grid(row=0, column=2, padx=5)

        self.loop_var = tk.StringVar(value="1")

        tk.OptionMenu(
            speed_frame,
            self.loop_var,
            "1",
            "2",
            "5",
            "10",
            "50",
            "100",
            "500",
            "1000",
            "∞ Infinite"
        ).grid(row=0, column=3, padx=5)

        # --------------------------------------------------------
        # BUTTONS
        # --------------------------------------------------------

        btn_frame = tk.Frame(left_frame, bg="black")
        btn_frame.pack(pady=5)

        self.record_button = tk.Button(
            btn_frame,
            text="⏺ Record",
            width=12,
            command=self.toggle_recording
        )
        self.record_button.grid(row=0, column=0, padx=5)

        # IMPORTANT:
        # This is now a toggle instead of directly calling
        # start_playback().
        self.play_button = tk.Button(
            btn_frame,
            text="▶ Play",
            width=12,
            command=self.toggle_playback
        )
        self.play_button.grid(row=0, column=1, padx=5)

        self.delete_button = tk.Button(
            btn_frame,
            text="🗑 Delete",
            width=12,
            command=self.delete_selected
        )
        self.delete_button.grid(row=0, column=2, padx=5)

        self.rename_button = tk.Button(
            btn_frame,
            text="✏ Rename",
            width=12,
            command=self.rename_selected
        )
        self.rename_button.grid(row=0, column=3, padx=5)

        self.export_button = tk.Button(
            btn_frame,
            text="📦 Export All",
            width=12,
            command=self.export_all_macros
        )
        self.export_button.grid(row=0, column=4, padx=5)

        # --------------------------------------------------------
        # MACRO LIST
        # --------------------------------------------------------

        tk.Label(
            left_frame,
            text="Recorded Macros:",
            fg="white",
            bg="black"
        ).pack()

        list_frame = tk.Frame(left_frame, bg="black")
        list_frame.pack(pady=5, fill="x")

        self.listbox = tk.Listbox(
            list_frame,
            width=50,
            height=10
        )
        self.listbox.pack(
            side="left",
            fill="x",
            expand=True
        )

        list_scroll = tk.Scrollbar(
            list_frame,
            orient="vertical",
            command=self.listbox.yview
        )
        list_scroll.pack(side="right", fill="y")

        self.listbox.configure(
            yscrollcommand=list_scroll.set
        )

        self.listbox.bind(
            "<MouseWheel>",
            self.on_macro_list_mousewheel
        )

        self.listbox.bind(
            "<Button-4>",
            self.on_macro_list_mousewheel
        )

        self.listbox.bind(
            "<Button-5>",
            self.on_macro_list_mousewheel
        )

        self.listbox.bind(
            "<<ListboxSelect>>",
            self.on_macro_selected
        )

        self.refresh_macro_list()

        # --------------------------------------------------------
        # ADVANCED SETTINGS
        # --------------------------------------------------------

        self.adv_frame = tk.Frame(
            left_frame,
            bg="gray15",
            bd=1,
            relief="ridge"
        )
        self.adv_frame.pack(fill="x", pady=5)

        self.adv_open = False

        self.adv_toggle_btn = tk.Button(
            self.adv_frame,
            text="Advanced Settings ▼",
            command=self.toggle_advanced,
            bg="gray20",
            fg="white",
            relief="flat"
        )
        self.adv_toggle_btn.pack(fill="x")

        self.adv_inner = tk.Frame(
            self.adv_frame,
            bg="gray15"
        )

        tk.Label(
            self.adv_inner,
            text="Hotkeys",
            fg="white",
            bg="gray15"
        ).pack(pady=(5, 0))

        tk.Frame(
            self.adv_inner,
            bg="gray30",
            height=1
        ).pack(fill="x", padx=5, pady=2)

        hk_frame = tk.Frame(
            self.adv_inner,
            bg="gray15"
        )
        hk_frame.pack(pady=5)

        tk.Label(
            hk_frame,
            text="Record Hotkey:",
            fg="white",
            bg="gray15"
        ).grid(row=0, column=0, padx=5, sticky="e")

        self.record_hotkey_label = tk.Label(
            hk_frame,
            text=self.record_hotkey or "None",
            fg="cyan",
            bg="gray15"
        )
        self.record_hotkey_label.grid(
            row=0,
            column=1,
            padx=5,
            sticky="w"
        )

        tk.Button(
            hk_frame,
            text="Set",
            command=self.set_record_hotkey
        ).grid(row=0, column=2, padx=5)

        tk.Label(
            hk_frame,
            text="Playback Hotkey:",
            fg="white",
            bg="gray15"
        ).grid(row=1, column=0, padx=5, sticky="e")

        self.play_hotkey_label = tk.Label(
            hk_frame,
            text=self.play_hotkey or "None",
            fg="cyan",
            bg="gray15"
        )
        self.play_hotkey_label.grid(
            row=1,
            column=1,
            padx=5,
            sticky="w"
        )

        tk.Button(
            hk_frame,
            text="Set",
            command=self.set_play_hotkey
        ).grid(row=1, column=2, padx=5)
# ============================================================
# SCHEDULING UI
# ============================================================
        tk.Frame(
            self.adv_inner,
            bg="gray30",
            height=1
        ).pack(fill="x", padx=5, pady=2)

        tk.Label(
            self.adv_inner,
            text="Macro Scheduler",
            fg="white",
            bg="gray15"
        ).pack(pady=(5, 0))

        schedule_frame = tk.Frame(
            self.adv_inner,
            bg="gray15"
        )
        schedule_frame.pack(pady=5)

        self.current_time_label = tk.Label(
            schedule_frame,
            text="Current Time: --:--:--",
            fg="cyan",
            bg="gray15"
        )
        self.current_time_label.grid(
            row=0,
            column=0,
            columnspan=3,
            pady=3
        )

        tk.Label(
            schedule_frame,
            text="Trigger Time:",
            fg="white",
            bg="gray15"
        ).grid(
            row=1,
            column=0,
            padx=5
        )

        self.schedule_time_var = tk.StringVar(
            value="12:00 PM"
        )

        self.schedule_time_entry = tk.Entry(
            schedule_frame,
            textvariable=self.schedule_time_var,
            width=12,
            bg="gray25",
            fg="white"
        )

        self.schedule_time_entry.grid(
            row=1,
            column=1,
            padx=5
        )

        tk.Button(
            schedule_frame,
            text="Set",
            command=self.set_macro_schedule
        ).grid(
            row=1,
            column=2,
            padx=5
        )

        tk.Button(
            schedule_frame,
            text="Clear",
            command=self.clear_macro_schedule
        ).grid(
            row=2,
            column=0,
            columnspan=3,
            pady=3
        )

        self.schedule_status_label = tk.Label(
            schedule_frame,
            text="No schedule set",
            fg="white",
            bg="gray15"
        )

        self.schedule_status_label.grid(
            row=3,
            column=0,
            columnspan=3,
            pady=3
        )

        self.update_current_time()

        tk.Frame(
            self.adv_inner,
            bg="gray30",
            height=1
        ).pack(fill="x", padx=5, pady=2)

        tk.Label(
            self.adv_inner,
            text="Recording Mode",
            fg="white",
            bg="gray15"
        ).pack(pady=(5, 0))

        tk.Frame(
            self.adv_inner,
            bg="gray30",
            height=1
        ).pack(fill="x", padx=5, pady=2)

        mode_frame = tk.Frame(
            self.adv_inner,
            bg="gray15"
        )
        mode_frame.pack(pady=5)

        tk.Radiobutton(
            mode_frame,
            text="Relative Movement",
            variable=self.record_mode,
            value="relative",
            fg="white",
            bg="gray15",
            selectcolor="gray25"
        ).grid(row=0, column=0, padx=5)

        tk.Radiobutton(
            mode_frame,
            text="Exact Coordinates",
            variable=self.record_mode,
            value="absolute",
            fg="white",
            bg="gray15",
            selectcolor="gray25"
        ).grid(row=0, column=1, padx=5)

        tk.Frame(
            self.adv_inner,
            bg="gray30",
            height=1
        ).pack(fill="x", padx=5, pady=2)

        tk.Label(
            self.adv_inner,
            text=(
                "• Hotkeys are global\n"
                "• Saved to hotkeys.cfg; key names use keymap.json\n"
                "• Not recorded into macros\n"
                "• Recording mode affects new recordings only"
            ),
            fg="white",
            bg="gray15",
            justify="left"
        ).pack(pady=5)

        # --------------------------------------------------------
        # VOICE
        # --------------------------------------------------------

        voice_frame_outer = tk.Frame(
            self.adv_inner,
            bg="gray15"
        )
        voice_frame_outer.pack(
            fill="x",
            padx=5,
            pady=5
        )

        self.voice_open = False

        self.voice_toggle_btn = tk.Button(
            voice_frame_outer,
            text="Voice Control ▼",
            bg="gray20",
            fg="white",
            relief="flat",
            command=self.toggle_voice_panel
        )
        self.voice_toggle_btn.pack(fill="x")

        self.voice_inner = tk.Frame(
            voice_frame_outer,
            bg="gray18"
        )

        tk.Label(
            self.voice_inner,
            text="Voice Trigger Phrase:",
            fg="white",
            bg="gray18"
        ).pack(pady=(5, 0))

        self.voice_entry = tk.Entry(
            self.voice_inner,
            textvariable=self.voice_phrase,
            bg="gray25",
            fg="white"
        )
        self.voice_entry.pack(
            fill="x",
            padx=5,
            pady=3
        )

        self.voice_bind_btn = tk.Button(
            self.voice_inner,
            text="Bind Phrase to Selected Macro",
            command=self.bind_voice_to_selected_macro
        )
        self.voice_bind_btn.pack(pady=3)

        tk.Label(
            self.voice_inner,
            text="Microphone:",
            fg="white",
            bg="gray18"
        ).pack(pady=(5, 0))

        devices = self.get_input_devices()

        if devices:
            self.voice_device.set(devices[0])

        self.voice_device_menu = tk.OptionMenu(
            self.voice_inner,
            self.voice_device,
            *devices
        )
        self.voice_device_menu.config(
            bg="gray25",
            fg="white"
        )
        self.voice_device_menu["menu"].config(
            bg="gray25",
            fg="white"
        )
        self.voice_device_menu.pack(pady=3)

        control_frame = tk.Frame(
            self.voice_inner,
            bg="gray18"
        )
        control_frame.pack(pady=5)

        self.voice_start_btn = tk.Button(
            control_frame,
            text="Start Voice Listener",
            command=self.start_voice_listener
        )
        self.voice_start_btn.grid(
            row=0,
            column=0,
            padx=5
        )

        self.voice_stop_btn = tk.Button(
            control_frame,
            text="Stop Voice Listener",
            command=self.stop_voice_listener,
            state=tk.DISABLED
        )
        self.voice_stop_btn.grid(
            row=0,
            column=1,
            padx=5
        )

        self.voice_status_label = tk.Label(
            self.voice_inner,
            text="Voice Listener: Stopped",
            fg="white",
            bg="gray18"
        )
        self.voice_status_label.pack(pady=5)

        # --------------------------------------------------------
        # GLOBAL LISTENERS
        # --------------------------------------------------------

        self.global_listener = pynput.keyboard.Listener(
            on_press=self.global_on_key_press,
            on_release=self.global_on_key_release
        )

        self.global_mouse_listener = pynput.mouse.Listener(
            on_click=self.global_on_click
        )

        self.global_listener.start()
        self.global_mouse_listener.start()

        self.assigning_record_hotkey = False
        self.assigning_play_hotkey = False


# ================================================================
# KEYMAP / VOICE
# ================================================================

    def load_keymap(self):
        try:
            if getattr(sys, "frozen", False):
                # Compiled executable:
                # Look beside the .exe
                base_dir = os.path.dirname(os.path.abspath(sys.executable))
            else:
                # Running as Python:
                # Look beside rapdi.py
                base_dir = os.path.dirname(os.path.abspath(__file__))

            path = os.path.join(base_dir, "keymap.json")

            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)

            return data if isinstance(data, dict) else {}

        except Exception:
            return {}


    def load_voice_bindings(self):
        try:
            if os.path.exists(self.voice_bindings_file):
                with open(
                    self.voice_bindings_file,
                    "r",
                    encoding="utf-8"
                ) as f:
                    data = json.load(f)

                    return (
                        data
                        if isinstance(data, dict)
                        else {}
                    )

        except Exception:
            pass

        return {}


    def save_voice_bindings(self):
        try:
            with open(
                self.voice_bindings_file,
                "w",
                encoding="utf-8"
            ) as f:
                json.dump(
                    self.voice_bindings,
                    f,
                    indent=2,
                    ensure_ascii=False
                )

        except Exception:
            pass

    def is_macro_voice_bound(self, filename):
        return bool(str(self.voice_bindings.get(filename, "")).strip())

    def load_schedule_bindings(self):
        try:
            if os.path.exists(self.schedule_bindings_file):
                with open(
                    self.schedule_bindings_file,
                    "r",
                    encoding="utf-8"
                ) as f:
                    data = json.load(f)

                    if isinstance(data, dict):
                        return data
        except Exception:
            pass

        return {}


    def save_schedule_bindings(self):
         try:
             with open(
                 self.schedule_bindings_file,
                 "w",
                 encoding="utf-8"
             ) as f:
                 json.dump(
                     self.schedule_bindings,
                     f,
                     indent=2,
                     ensure_ascii=False
                 )
         except Exception:
             pass
    def find_macro_by_voice_phrase(self, text):
        text = str(text).lower().strip()

        if not text:
            return None
   
        for filename, phrase in self.voice_bindings.items():
            phrase = str(phrase).lower().strip()

            if phrase and phrase in text:
                path = os.path.join(self.macro_folder, filename)

                if os.path.exists(path):
                    return path

        return None


# ================================================================
# MACRO LIST
# ================================================================

    def get_macro_filename_from_index(self, index):
        value = self.listbox.get(index)

        return (
            value[2:]
            if value.startswith("🔊 ")
            else value
        )


    def get_macro_display_name(self, filename):
        return (
            f"🔊 {filename}"
            if self.is_macro_voice_bound(filename)
            else filename
        )


    def on_macro_selected(self, event=None):
        try:
            sel = self.listbox.curselection()

            if not sel:
                return

            filename = self.get_macro_filename_from_index(
                sel[0]
            )

            self.voice_macro = os.path.join(
                self.macro_folder,
                filename
            )

            phrase = self.voice_bindings.get(
                filename,
                ""
            )

            if phrase:
                self.voice_phrase.set(phrase)
            schedule = self.schedule_bindings.get(filename)

            if schedule:
                self.schedule_time_var.set(schedule)

                self.schedule_status_label.config(
                    text=f"Scheduled for {schedule}"
                )
            else:
                self.schedule_time_var.set("12:00 PM")

                self.schedule_status_label.config(
                    text="No schedule set"
            )

        except Exception:
            pass


    def on_macro_list_mousewheel(self, event):
        try:
            count = self.listbox.size()

            if count == 0:
                return "break"

            selected = self.listbox.curselection()
            current = selected[0] if selected else 0

            if getattr(event, "num", None) == 5:
                step = 1

            elif getattr(event, "num", None) == 4:
                step = -1

            else:
                step = (
                    -1
                    if event.delta > 0
                    else 1
                )

            new_index = (current + step) % count

            self.listbox.selection_clear(
                0,
                tk.END
            )

            self.listbox.selection_set(new_index)
            self.listbox.activate(new_index)
            self.listbox.see(new_index)

            return "break"

        except Exception:
            return "break"


    def refresh_macro_list(self):
        self.listbox.delete(0, tk.END)

        files = sorted(
            glob.glob(
                os.path.join(
                    self.macro_folder,
                    "*.X"
                )
            )
        )

        for f in files:
            self.listbox.insert(
                tk.END,
                self.get_macro_display_name(
                    os.path.basename(f)
                )
            )


# ================================================================
# EXPORT / DELETE / RENAME
# ================================================================

    def export_all_macros(self):
        macro_files = sorted(
            glob.glob(
                os.path.join(
                    self.macro_folder,
                    "*.X"
                )
            )
        )

        if not macro_files:
            messagebox.showinfo(
                "Export Macros",
                "There are no macros to export."
            )
            return

        destination = filedialog.asksaveasfilename(
            parent=self,
            title="Export All Macros",
            defaultextension=".zip",
            filetypes=[
                ("ZIP archive", "*.zip")
            ]
        )

        if not destination:
            return

        try:
            with zipfile.ZipFile(
                destination,
                "w",
                zipfile.ZIP_DEFLATED
            ) as archive:

                for path in macro_files:
                    archive.write(
                        path,
                        arcname=os.path.basename(path)
                    )

                if os.path.exists(
                    self.voice_bindings_file
                ):
                    archive.write(
                        self.voice_bindings_file,
                        arcname="voice_bindings.json"
                    )

            messagebox.showinfo(
                "Export Complete",
                f"Exported {len(macro_files)} macro(s) to:\n"
                f"{destination}"
            )

        except Exception as exc:
            messagebox.showerror(
                "Export Failed",
                f"Could not create the ZIP archive:\n{exc}"
            )


    def delete_selected(self):
        sel = self.listbox.curselection()

        if not sel:
            return

        filename = self.get_macro_filename_from_index(
            sel[0]
        )

        path = os.path.join(
            self.macro_folder,
            filename
        )

        if os.path.exists(path):
            os.remove(path)

        if filename in self.voice_bindings:
            del self.voice_bindings[filename]
            self.save_voice_bindings()

        if self.voice_macro == path:
            self.voice_macro = None

        self.refresh_macro_list()


    def rename_selected(self):
        sel = self.listbox.curselection()

        if not sel:
            return

        old_name = self.get_macro_filename_from_index(
            sel[0]
        )

        old_path = os.path.join(
            self.macro_folder,
            old_name
        )

        new_name = simpledialog.askstring(
            "Rename Macro",
            "Enter new name (without extension):",
            parent=self
        )

        if not new_name:
            return

        for ch in '\\/:*?"<>|':
            new_name = new_name.replace(
                ch,
                "_"
            )

        new_name = new_name.strip()

        if not new_name:
            messagebox.showerror(
                "Error",
                "Invalid name."
            )
            return

        if not new_name.lower().endswith(".x"):
            new_name += ".X"

        new_path = os.path.join(
            self.macro_folder,
            new_name
        )

        if os.path.exists(new_path):
            messagebox.showerror(
                "Error",
                "A macro with that name already exists."
            )
            return

        os.rename(
            old_path,
            new_path
        )

        if old_name in self.voice_bindings:
            self.voice_bindings[new_name] = (
                self.voice_bindings.pop(old_name)
            )
            self.save_voice_bindings()

        if self.voice_macro == old_path:
            self.voice_macro = new_path

        self.refresh_macro_list()

        for i in range(self.listbox.size()):
            if (
                self.get_macro_filename_from_index(i)
                == new_name
            ):
                self.listbox.selection_set(i)
                self.listbox.activate(i)
                self.listbox.see(i)
                break


# ================================================================
# PANELS
# ================================================================

    def toggle_advanced(self):
        self.adv_open = not self.adv_open

        if self.adv_open:
            self.adv_inner.pack(
                fill="x",
                padx=5,
                pady=5
            )

            self.adv_toggle_btn.config(
                text="Advanced Settings ▲"
            )

        else:
            self.adv_inner.forget()

            self.adv_toggle_btn.config(
                text="Advanced Settings ▼"
            )


    def toggle_voice_panel(self):
        self.voice_open = not self.voice_open

        if self.voice_open:
            self.voice_inner.pack(
                fill="x",
                padx=5,
                pady=5
            )

            self.voice_toggle_btn.config(
                text="Voice Control ▲"
            )

        else:
            self.voice_inner.forget()

            self.voice_toggle_btn.config(
                text="Voice Control ▼"
            )


# ================================================================
# VOICE
# ================================================================

    def get_input_devices(self):
        try:
            devices = sd.query_devices()

        except Exception:
            return ["0: Default"]

        result = []

        for i, dev in enumerate(devices):
            if dev["max_input_channels"] > 0:
                result.append(
                    f"{i}: {dev['name']}"
                )

        return (
            result
            if result
            else ["0: Default"]
        )


    def get_selected_device_index(self):
        try:
            return int(
                self.voice_device
                .get()
                .split(":")[0]
            )

        except Exception:
            return None


    def bind_voice_to_selected_macro(self):
        sel = self.listbox.curselection()

        if not sel:
            messagebox.showerror(
                "Error",
                "No macro selected to bind."
            )
            return

        filename = self.get_macro_filename_from_index(
            sel[0]
        )

        phrase = self.voice_phrase.get().strip()

        path = os.path.join(
            self.macro_folder,
            filename
        )

        if not phrase:
            self.voice_bindings.pop(
                filename,
                None
            )

            self.save_voice_bindings()

            self.voice_macro = None

            self.refresh_macro_list()

            messagebox.showinfo(
                "Voice Control",
                f"Voice trigger removed from:\n{filename}"
            )

            return

        self.voice_macro = path

        self.voice_bindings[filename] = phrase

        self.save_voice_bindings()

        self.refresh_macro_list()

        for i in range(self.listbox.size()):
            if (
                self.get_macro_filename_from_index(i)
                == filename
            ):
                self.listbox.selection_set(i)
                self.listbox.activate(i)
                self.listbox.see(i)
                break

        messagebox.showinfo(
            "Voice Control",
            f"Phrase '{phrase}' bound to macro:\n{filename}"
        )


    def start_voice_listener(self):
        if self.voice_running:
            return

        if not self.voice_macro:
            messagebox.showerror(
                "Error",
                "No macro bound to voice phrase."
            )
            return

        device_index = self.get_selected_device_index()

        if device_index is None:
            messagebox.showerror(
                "Error",
                "No microphone selected."
            )
            return

        try:
            self.global_listener.stop()
            self.global_mouse_listener.stop()

        except Exception:
            pass

        self.voice_running = True

        self.voice_status_label.config(
            text="Voice Listener: Running"
        )

        self.voice_start_btn.config(
            state=tk.DISABLED
        )

        self.voice_stop_btn.config(
            state=tk.NORMAL
        )

        self.audio_buffer = b""

        try:
            self.voice_stream = sd.InputStream(
                samplerate=16000,
                channels=1,
                dtype="int16",
                device=device_index,
                callback=self.voice_audio_callback
            )

            self.voice_stream.start()

        except Exception as e:
            messagebox.showerror(
                "Error",
                f"Failed to start audio stream:\n{e}"
            )

            self.voice_running = False

            self.voice_status_label.config(
                text="Voice Listener: Stopped"
            )

            self.voice_start_btn.config(
                state=tk.NORMAL
            )

            self.voice_stop_btn.config(
                state=tk.DISABLED
            )

            return

        threading.Thread(
            target=self.voice_loop,
            daemon=True
        ).start()


    def stop_voice_listener(self):
        self.voice_running = False

        self.voice_status_label.config(
            text="Voice Listener: Stopped"
        )

        self.voice_start_btn.config(
            state=tk.NORMAL
        )

        self.voice_stop_btn.config(
            state=tk.DISABLED
        )

        try:
            if (
                hasattr(self, "voice_stream")
                and self.voice_stream
            ):
                self.voice_stream.stop()
                self.voice_stream.close()
                self.voice_stream = None

        except Exception:
            pass

        try:
            self.global_listener = pynput.keyboard.Listener(
                on_press=self.global_on_key_press,
                on_release=self.global_on_key_release
            )

            self.global_mouse_listener = pynput.mouse.Listener(
                on_click=self.global_on_click
            )

            self.global_listener.start()
            self.global_mouse_listener.start()

        except Exception:
            pass


    def voice_audio_callback(
        self,
        indata,
        frames,
        time_info,
        status
    ):
        self.audio_buffer += indata.tobytes()

        if len(self.audio_buffer) > 16000 * 8:
            self.audio_buffer = self.audio_buffer[-16000 * 8:]


    def voice_loop(self):
        while self.voice_running:
            if len(self.audio_buffer) < 16000 * 2:
                time.sleep(.1)
                continue

            audio_bytes = bytes(self.audio_buffer)
            audio_obj = sr.AudioData(audio_bytes, 16000, 2)

            try:
                text = self.recognizer.recognize_google(audio_obj).lower().strip()

                macro_path = self.find_macro_by_voice_phrase(text)

                if macro_path and not self.playing_back and not self.recording:
                    self.voice_macro = macro_path
                    self.current_macro = macro_path

                    filename = os.path.basename(macro_path)

                    for i in range(self.listbox.size()):
                        if self.get_macro_filename_from_index(i) == filename:
                            self.listbox.selection_clear(0, tk.END)
                            self.listbox.selection_set(i)
                            self.listbox.activate(i)
                            self.listbox.see(i)
                            break

                    self.voice_status_label.config(
                        text=f"Voice Listener: Playing → {filename}"
                    )

                    self.playing_back = True
                    self.playback_pressed_keys = set()
                    self.playback_modifier_state = set()

                    try:
                        self.playback_speed = float(
                            self.speed_var.get().replace("x", "")
                        )
                    except Exception:
                        self.playback_speed = 1.0

                    if self.loop_var.get() == "∞ Infinite":
                        self.loop_infinite = True
                        self.loop_count = 1
                    else:
                        self.loop_infinite = False
                        self.loop_count = int(self.loop_var.get())

                    self.play_button.config(text="⏸ Playing")

                    threading.Thread(
                        target=self.playback_thread,
                        daemon=True
                    ).start()

                    self.audio_buffer = b""
                    time.sleep(.3)
                    continue

            except sr.UnknownValueError:
                pass

            except sr.RequestError:
                self.voice_status_label.config(
                    text="Voice Listener: API error"
                )

            time.sleep(.25)
            
    def scheduler_loop(self):
        while self.scheduler_running:
            try:
                now = datetime.now()
                current_time = now.strftime("%I:%M %p")

                for filename, trigger_time in list(
                    self.schedule_bindings.items()
                ):
                    if str(trigger_time).upper() != current_time.upper():
                        continue

                    macro_path = os.path.join(
                        self.macro_folder,
                        filename
                    )

                    if not os.path.exists(macro_path):
                        continue

                    today_key = (
                        f"{now.strftime('%Y-%m-%d')}|{filename}|{current_time}"
                    )

                    if self.scheduler_last_trigger.get(filename) == today_key:
                        continue

                    self.scheduler_last_trigger[filename] = today_key

                    if not self.playing_back and not self.recording:
                        self.launch_scheduled_macro(macro_path)

            except Exception:
                pass

            time.sleep(1)

    def update_current_time(self):
        try:
            now = datetime.now()

            self.current_time_label.config(
                text=f"Current Time: {now.strftime('%I:%M:%S %p')}"
            )

            self.after(1000, self.update_current_time)

        except Exception:
            pass

    def set_macro_schedule(self):
        sel = self.listbox.curselection()

        if not sel:
            messagebox.showerror(
                "Scheduler",
                "Select a macro first."
            )
            return

        filename = self.get_macro_filename_from_index(
            sel[0]
        )

        trigger_time = self.schedule_time_var.get().strip().upper()

        try:
            parsed = datetime.strptime(
                trigger_time,
                "%I:%M %p"
            )

            normalized_time = parsed.strftime(
                "%I:%M %p"
            )

        except ValueError:
            messagebox.showerror(
                "Scheduler",
                "Invalid time.\n\nUse the format:\n04:30 PM"
            )
            return

        self.schedule_bindings[filename] = normalized_time

        self.save_schedule_bindings()

        self.schedule_status_label.config(
            text=f"{filename} scheduled for {normalized_time}"
        )

    def clear_macro_schedule(self):
        sel = self.listbox.curselection()

        if not sel:
            messagebox.showerror(
                "Scheduler",
                "Select a macro first."
            )
            return

        filename = self.get_macro_filename_from_index(
            sel[0]
        )

        if filename in self.schedule_bindings:
            del self.schedule_bindings[filename]

            self.save_schedule_bindings()

        self.schedule_status_label.config(
            text=f"No schedule set for {filename}"
        )

    def launch_scheduled_macro(self, macro_path):
        try:
            if self.playing_back or self.recording:
                return

            filename = os.path.basename(macro_path)

            self.current_macro = macro_path

            for i in range(self.listbox.size()):
                if self.get_macro_filename_from_index(i) == filename:
                    self.listbox.selection_clear(0, tk.END)
                    self.listbox.selection_set(i)
                    self.listbox.activate(i)
                    self.listbox.see(i)
                    break

            self.start_playback()

        except Exception:
            pass         
# ================================================================
# RECORDING
# ================================================================

    def toggle_recording(self):
        if self.playing_back:
            return

        self.recording = not self.recording

        if self.recording:

            self.events = []
            self.start_time = time.time()

            self.record_mod_ctrl = False
            self.record_mod_shift = False
            self.record_mod_alt = False
            self.record_mod_cmd = False

            self.record_button.config(
                text="⏹ Stop"
            )

            self.last_x = None
            self.last_y = None

            self.key_listener = KeyListener(
                on_press=self.on_key_press,
                on_release=self.on_key_release
            )

            self.mouse_listener = MouseListener(
                on_click=self.on_click,
                on_scroll=self.on_scroll,
                on_move=self.on_move
            )

            self.key_listener.start()
            self.mouse_listener.start()

        else:

            self.record_button.config(
                text="⏺ Record"
            )

            try:
                self.key_listener.stop()
                self.mouse_listener.stop()

            except Exception:
                pass

            self.record_mod_ctrl = False
            self.record_mod_shift = False
            self.record_mod_alt = False
            self.record_mod_cmd = False

            count = (
                len(
                    glob.glob(
                        os.path.join(
                            self.macro_folder,
                            "*.X"
                        )
                    )
                )
                + 1
            )

            path = os.path.join(
                self.macro_folder,
                f"macro_{count:03d}.X"
            )

            cleaned_events = self.sanitize_macro_events(
                self.events
            )

            with open(
                path,
                "w",
                encoding="utf-8"
            ) as f:

                for event in cleaned_events:
                    f.write(event + "\n")

            self.events = cleaned_events

            self.refresh_macro_list()


    def record_event(self, etype, data):
        if self.recording:
            self.events.append(
                f"TIME={time.time() - self.start_time:.4f} "
                f"TYPE={etype} DATA={data}"
            )


# ================================================================
# KEY NORMALIZATION
# ================================================================

    def _canonical_modifier(self, key):

        if key in (
            Key.ctrl,
            Key.ctrl_l,
            Key.ctrl_r
        ):
            return "Ctrl"

        if key in (
            Key.shift,
            Key.shift_l,
            Key.shift_r
        ):
            return "Shift"

        if key in (
            Key.alt,
            Key.alt_l,
            Key.alt_r
        ):
            return "Alt"

        if key in (
            Key.cmd,
            Key.cmd_l,
            Key.cmd_r
        ):
            return "Cmd"

        return None


    def _is_modifier_key(self, key):
        return self._canonical_modifier(key) is not None


    def _set_modifier_state(self, key, pressed):
        m = self._canonical_modifier(key)

        if m == "Ctrl":
            self.mod_ctrl = pressed

        elif m == "Shift":
            self.mod_shift = pressed

        elif m == "Alt":
            self.mod_alt = pressed

        elif m == "Cmd":
            self.mod_cmd = pressed


    def _get_modifier_prefix(self):
        p = []

        if self.mod_ctrl:
            p.append("Ctrl")

        if self.mod_shift:
            p.append("Shift")

        if self.mod_alt:
            p.append("Alt")

        if self.mod_cmd:
            p.append("Cmd")

        return p


    def _control_char_to_base(self, ch):
        if not isinstance(ch, str):
            return None

        if len(ch) != 1:
            return None

        code = ord(ch)

        if 1 <= code <= 26:
            return chr(code + 96).upper()

        return {
            27: "[",
            28: "\\",
            29: "]",
            30: "^",
            31: "_"
        }.get(code)


    def _is_raw_control_key_id(self, value):
        if value is None:
            return False

        value = str(value)

        if len(value) == 1:
            try:
                if ord(value) < 32:
                    return True

            except Exception:
                pass

        return value.lower() in {
            f"\\x{i:02x}"
            for i in range(1, 32)
        }


    def _keymap_special_lookup(self, key):
        try:
            if (
                hasattr(key, "char")
                and key.char is not None
            ):
                ch = key.char

                if (
                    len(ch) == 1
                    and ord(ch) >= 32
                ):
                    return ch

                if self._control_char_to_base(ch) is not None:
                    return None

        except Exception:
            pass

        raw = str(key)
        name = raw.replace("Key.", "")

        for candidate in (
            raw,
            f"Key.{name}",
            name
        ):

            if candidate in self.keymap:
                value = self.keymap[candidate]

                if not self._is_raw_control_key_id(value):
                    return str(value)

        return None


    def normalize_recorded_key(self, key):

        m = self._canonical_modifier(key)

        if m:
            return m

        try:
            if (
                hasattr(key, "char")
                and key.char is not None
            ):
                ch = key.char

                # IMPORTANT:
                # pynput can produce control characters when
                # Ctrl is held. Convert those back to the actual
                # printable base key rather than recording the
                # control character itself.
                base = self._control_char_to_base(ch)

                if base is not None:
                    return base.lower()

                if (
                    len(ch) == 1
                    and ord(ch) >= 32
                ):
                    return ch

        except Exception:
            pass

        mapped = self._keymap_special_lookup(key)

        if (
            mapped is None
            or self._is_raw_control_key_id(mapped)
        ):
            return None

        if str(mapped).lower() in {
            "ctrl",
            "ctrl_l",
            "ctrl_r",
            "shift",
            "shift_l",
            "shift_r",
            "alt",
            "alt_l",
            "alt_r",
            "cmd",
            "cmd_l",
            "cmd_r"
        }:
            return None

        return str(mapped)


# ================================================================
# RECORD VALIDATION
# ================================================================

    def is_valid_recording_key(self, key_name):
        if key_name is None:
            return False

        key_name = str(key_name)

        if not key_name:
            return False

        upper = key_name.upper()

        if upper in {
            "CTRL",
            "SHIFT",
            "ALT",
            "CMD"
        }:
            return True

        if len(key_name) == 1:
            try:
                return ord(key_name) >= 32

            except Exception:
                return False

        if key_name.startswith("Key."):
            try:
                getattr(
                    Key,
                    key_name[4:]
                )
                return True

            except AttributeError:
                return False

        aliases = {
            "ENTER",
            "RETURN",
            "TAB",
            "SPACE",
            "BACKSPACE",
            "ESC",
            "ESCAPE",
            "DELETE",
            "INSERT",
            "HOME",
            "END",
            "PAGEUP",
            "PAGEDOWN",
            "UP",
            "DOWN",
            "LEFT",
            "RIGHT",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12"
        }

        if upper in aliases:
            return True

        if key_name in self.keymap:
            mapped = self.keymap.get(key_name)

            if (
                mapped is None
                or self._is_raw_control_key_id(mapped)
            ):
                return False

            if str(mapped) == key_name:
                return False

            return self.is_valid_recording_key(
                str(mapped)
            )

        return False


    def sanitize_macro_events(self, events):
        cleaned = []

        valid_types = {
            "KEY_DOWN",
            "KEY_UP",
            "MOUSE_MOVE",
            "MOUSE_MOVE_ABS",
            "MOUSE_CLICK",
            "MOUSE_SCROLL"
        }

        for event in events:

            if not isinstance(event, str):
                continue

            line = event.strip()

            if not line.startswith("TIME="):
                continue

            parts = line.split()

            if len(parts) < 3:
                continue

            try:
                t = float(
                    parts[0].split("=", 1)[1]
                )

                etype = (
                    parts[1]
                    .split("=", 1)[1]
                )

                data = (
                    parts[2]
                    .split("=", 1)[1]
                )

            except Exception:
                continue

            if etype not in valid_types:
                continue

            if etype in {
                "KEY_DOWN",
                "KEY_UP"
            }:

                if not self.is_valid_recording_key(data):
                    continue

            elif etype == "MOUSE_MOVE":

                try:
                    dx, dy = map(
                        int,
                        data.split(":")
                    )

                    data = f"{dx}:{dy}"

                except Exception:
                    continue

            elif etype == "MOUSE_MOVE_ABS":

                try:
                    x, y = map(
                        int,
                        data.split(":")
                    )

                    data = f"{x}:{y}"

                except Exception:
                    continue

            elif etype == "MOUSE_CLICK":

                try:
                    button, pressed = data.split(
                        ":",
                        1
                    )

                    if (
                        button not in {
                            "left",
                            "right"
                        }
                        or pressed not in {
                            "True",
                            "False"
                        }
                    ):
                        continue

                except Exception:
                    continue

            elif etype == "MOUSE_SCROLL":

                try:
                    data = str(int(data))

                except Exception:
                    continue

            cleaned.append(
                f"TIME={t:.4f} "
                f"TYPE={etype} "
                f"DATA={data}"
            )

        return cleaned


# ================================================================
# RECORD KEY EVENTS
# ================================================================

    def on_key_press(self, key):
        if self.is_hotkey_key(key):
            return

        self._set_record_modifier_state(
            key,
            True
        )

        norm = self.normalize_recorded_key(key)

        if norm is not None:
            self.record_event(
                "KEY_DOWN",
                norm
            )


    def on_key_release(self, key):
        if self.is_hotkey_key(key):
            return

        norm = self.normalize_recorded_key(key)

        if norm is not None:
            self.record_event(
                "KEY_UP",
                norm
            )

        self._set_record_modifier_state(
            key,
            False
        )


    def _set_record_modifier_state(
        self,
        key,
        pressed
    ):
        m = self._canonical_modifier(key)

        if m == "Ctrl":
            self.record_mod_ctrl = pressed

        elif m == "Shift":
            self.record_mod_shift = pressed

        elif m == "Alt":
            self.record_mod_alt = pressed

        elif m == "Cmd":
            self.record_mod_cmd = pressed


# ================================================================
# RECORD MOUSE
# ================================================================

    def on_click(
        self,
        x,
        y,
        button,
        pressed
    ):
        if self.is_hotkey_mouse(button):
            return

        btn = (
            "left"
            if button == Button.left
            else "right"
        )

        self.record_event(
            "MOUSE_CLICK",
            f"{btn}:{pressed}"
        )


    def on_scroll(
        self,
        x,
        y,
        dx,
        dy
    ):
        self.record_event(
            "MOUSE_SCROLL",
            str(dy)
        )


    def on_move(self, x, y):
        if self.record_mode.get() == "relative":

            if self.last_x is None:
                self.last_x = x
                self.last_y = y
                return

            dx = x - self.last_x
            dy = y - self.last_y

            self.last_x = x
            self.last_y = y

            self.record_event(
                "MOUSE_MOVE",
                f"{dx}:{dy}"
            )

        else:
            self.record_event(
                "MOUSE_MOVE_ABS",
                f"{x}:{y}"
            )


# ================================================================
# PLAYBACK
# ================================================================

    def toggle_playback(self):
        """
        Simple playback button toggle.

        This intentionally stays separate from the playback engine.
        The engine itself remains essentially unchanged.
        """

        if self.recording:
            return

        if self.playing_back:
            self.stop_playback()

        else:
            self.start_playback()


    def start_playback(self):

        if self.recording or self.playing_back:
            return

        sel = self.listbox.curselection()

        if not sel:
            return

        filename = self.get_macro_filename_from_index(
            sel[0]
        )

        self.current_macro = os.path.join(
            self.macro_folder,
            filename
        )

        try:
            self.playback_speed = float(
                self.speed_var
                .get()
                .replace("x", "")
            )

        except Exception:
            self.playback_speed = 1.0

        if self.loop_var.get() == "∞ Infinite":

            self.loop_infinite = True
            self.loop_count = 1

        else:

            self.loop_infinite = False

            try:
                self.loop_count = int(
                    self.loop_var.get()
                )

            except Exception:
                self.loop_count = 1

        self.playing_back = True

        # Fresh playback state for every playback.
        self.playback_pressed_keys = set()
        self.playback_modifier_state = set()

        self.play_button.config(
            text="⏸ Playing"
        )

        threading.Thread(
            target=self.playback_thread,
            daemon=True
        ).start()


    def stop_playback(self):
        self.playing_back = False


    def playback_thread(self):

        events = []

        try:

            with open(
                self.current_macro,
                "r",
                encoding="utf-8"
            ) as f:

                for line in f:

                    line = line.strip()

                    if not line.startswith("TIME="):
                        continue

                    parts = line.split()

                    if len(parts) < 3:
                        continue

                    try:
                        t = float(
                            parts[0]
                            .split("=", 1)[1]
                        )

                        etype = (
                            parts[1]
                            .split("=", 1)[1]
                        )

                        data = (
                            parts[2]
                            .split("=", 1)[1]
                        )

                    except Exception:
                        continue

                    if etype in {
                        "KEY_DOWN",
                        "KEY_UP"
                    }:

                        if self.parse_key(data) is None:
                            continue

                    elif etype == "MOUSE_MOVE":

                        try:
                            x, y = map(
                                int,
                                data.split(":")
                            )

                            data = f"{x}:{y}"

                        except Exception:
                            continue

                    elif etype == "MOUSE_MOVE_ABS":

                        try:
                            x, y = map(
                                int,
                                data.split(":")
                            )

                            data = f"{x}:{y}"

                        except Exception:
                            continue

                    elif etype == "MOUSE_CLICK":

                        try:
                            button, pressed = data.split(
                                ":",
                                1
                            )

                            if (
                                button not in {
                                    "left",
                                    "right"
                                }
                                or pressed not in {
                                    "True",
                                    "False"
                                }
                            ):
                                continue

                        except Exception:
                            continue

                    elif etype == "MOUSE_SCROLL":

                        try:
                            data = str(int(data))

                        except Exception:
                            continue

                    else:
                        continue

                    events.append(
                        (t, etype, data)
                    )

        except Exception as exc:

            self.playing_back = False

            try:
                self.parent.after(
                    0,
                    lambda e=exc: messagebox.showerror(
                        "Playback Error",
                        f"Could not read the macro:\n{e}"
                    )
                )

            except Exception:
                pass

            return

        loops_done = 0

        try:

            while self.playing_back:

                loops_done += 1

                start = time.time()
                idx = 0

                while (
                    idx < len(events)
                    and self.playing_back
                ):

                    now = (
                        time.time() - start
                    ) * self.playback_speed

                    t, etype, data = events[idx]

                    if now >= t:

                        self.apply_event(
                            etype,
                            data
                        )

                        idx += 1

                    else:
                        time.sleep(0.0005)

                if (
                    not self.loop_infinite
                    and loops_done >= self.loop_count
                ):
                    break

        finally:

            self.playing_back = False

            # IMPORTANT:
            # Release only keys that playback itself believes
            # it pressed. This prevents modifier/key state from
            # leaking into the next macro and is part of the
            # random-character / stuck-key protection.
            self.cleanup_stuck_keys()

            try:
                self.parent.after(
                    0,
                    lambda: self.play_button.config(
                        text="▶ Play"
                    )
                )

            except Exception:
                pass


# ================================================================
# PLAYBACK KEY PARSER
# ================================================================

    def parse_key(self, k):

        if not isinstance(k, str):
            return None

        k = k.strip()

        if not k:
            return None

        modifier_aliases = {
            "CTRL": Key.ctrl,
            "CTRL_L": Key.ctrl_l,
            "CTRL_R": Key.ctrl_r,

            "SHIFT": Key.shift,
            "SHIFT_L": Key.shift_l,
            "SHIFT_R": Key.shift_r,

            "ALT": Key.alt,
            "ALT_L": Key.alt_l,
            "ALT_R": Key.alt_r,

            "CMD": Key.cmd,
            "CMD_L": Key.cmd_l,
            "CMD_R": Key.cmd_r
        }

        upper = k.upper()

        if upper in modifier_aliases:
            return modifier_aliases[upper]

        # Printable character protection.
        #
        # Control characters are deliberately rejected here.
        # A recorded Ctrl+A, for example, must be represented
        # as Ctrl + "a", not as ASCII 1.
        if len(k) == 1:

            if (
                ord(k) < 32
                or ord(k) == 127
            ):
                return None

            return k

        if k.startswith("Key."):

            try:
                return getattr(
                    Key,
                    k[4:]
                )

            except AttributeError:
                return None

        aliases = {
            "ENTER": Key.enter,
            "RETURN": Key.enter,
            "TAB": Key.tab,
            "SPACE": Key.space,

            "BACKSPACE": Key.backspace,

            "ESC": Key.esc,
            "ESCAPE": Key.esc,

            "DELETE": Key.delete,
            "INSERT": Key.insert,

            "HOME": Key.home,
            "END": Key.end,

            "PAGEUP": Key.page_up,
            "PAGE_UP": Key.page_up,

            "PAGEDOWN": Key.page_down,
            "PAGE_DOWN": Key.page_down,

            "UP": Key.up,
            "DOWN": Key.down,
            "LEFT": Key.left,
            "RIGHT": Key.right,

            "F1": Key.f1,
            "F2": Key.f2,
            "F3": Key.f3,
            "F4": Key.f4,
            "F5": Key.f5,
            "F6": Key.f6,
            "F7": Key.f7,
            "F8": Key.f8,
            "F9": Key.f9,
            "F10": Key.f10,
            "F11": Key.f11,
            "F12": Key.f12
        }

        if upper in aliases:
            return aliases[upper]

        if k in self.keymap:

            mapped = self.keymap.get(k)

            if (
                mapped is None
                or self._is_raw_control_key_id(mapped)
            ):
                return None

            mapped = str(mapped)

            if mapped == k:
                return None

            return self.parse_key(mapped)

        return None


# ================================================================
# APPLY PLAYBACK EVENT
# ================================================================

    def apply_event(self, etype, data):

        if etype == "KEY_DOWN":

            key = self.parse_key(data)

            if key is None:
                return

            try:

                self.keyboard.press(key)

                # Track exactly what playback pressed.
                self.playback_pressed_keys.add(key)

                if self._is_modifier_key(key):
                    self.playback_modifier_state.add(key)

            except Exception:
                pass

        elif etype == "KEY_UP":

            key = self.parse_key(data)

            if key is None:
                return

            try:

                self.keyboard.release(key)

                self.playback_pressed_keys.discard(key)

                if self._is_modifier_key(key):
                    self.playback_modifier_state.discard(key)

            except Exception:
                pass

        elif etype == "MOUSE_MOVE":

            try:
                dx, dy = map(
                    int,
                    data.split(":")
                )

                send_mouse_move(
                    dx,
                    dy
                )

            except Exception:
                pass

        elif etype == "MOUSE_MOVE_ABS":

            try:
                x, y = map(
                    int,
                    data.split(":")
                )

                send_mouse_move_absolute(
                    x,
                    y
                )

            except Exception:
                pass

        elif etype == "MOUSE_CLICK":

            try:

                btn, pressed = data.split(
                    ":",
                    1
                )

                if btn in {
                    "left",
                    "right"
                }:
                    send_mouse_click(
                        btn,
                        pressed == "True"
                    )

            except Exception:
                pass

        elif etype == "MOUSE_SCROLL":

            try:
                send_mouse_scroll(
                    int(data)
                )

            except Exception:
                pass


    def cleanup_stuck_keys(self):

        pressed = list(
            getattr(
                self,
                "playback_pressed_keys",
                set()
            )
        )

        for key in pressed:

            try:
                self.keyboard.release(key)

            except Exception:
                pass

        self.playback_pressed_keys.clear()
        self.playback_modifier_state.clear()


# ================================================================
# HOTKEY CONFIG
# ================================================================

    def load_hotkeys(self):

        config = configparser.ConfigParser()

        if os.path.exists(self.config_file):

            config.read(self.config_file)

            self.record_hotkey = (
                config.get(
                    "hotkeys",
                    "record",
                    fallback=None
                )
                or None
            )

            self.play_hotkey = (
                config.get(
                    "hotkeys",
                    "play",
                    fallback=None
                )
                or None
            )

        else:

            self.record_hotkey = None
            self.play_hotkey = None


    def save_hotkeys(self):

        config = configparser.ConfigParser()

        config["hotkeys"] = {}

        config["hotkeys"]["record"] = (
            self.record_hotkey or ""
        )

        config["hotkeys"]["play"] = (
            self.play_hotkey or ""
        )

        with open(
            self.config_file,
            "w"
        ) as f:
            config.write(f)


# ================================================================
# HOTKEY ASSIGNMENT
# ================================================================

    def set_record_hotkey(self):

        self.assigning_record_hotkey = True
        self.assigning_play_hotkey = False

        self.record_hotkey_label.config(
            text="Press any key or mouse..."
        )


    def set_play_hotkey(self):

        self.assigning_play_hotkey = True
        self.assigning_record_hotkey = False

        self.play_hotkey_label.config(
            text="Press any key or mouse..."
        )


    def finalize_hotkey(self, hotkey_str):

        if self.assigning_record_hotkey:

            if hotkey_str == self.play_hotkey:

                messagebox.showerror(
                    "Error",
                    "Record hotkey cannot match playback hotkey."
                )

                self.record_hotkey_label.config(
                    text=self.record_hotkey or "None"
                )

            else:

                self.record_hotkey = hotkey_str

                self.record_hotkey_label.config(
                    text=self.record_hotkey
                )

        elif self.assigning_play_hotkey:

            if hotkey_str == self.record_hotkey:

                messagebox.showerror(
                    "Error",
                    "Playback hotkey cannot match record hotkey."
                )

                self.play_hotkey_label.config(
                    text=self.play_hotkey or "None"
                )

            else:

                self.play_hotkey = hotkey_str

                self.play_hotkey_label.config(
                    text=self.play_hotkey
                )

        self.assigning_record_hotkey = False
        self.assigning_play_hotkey = False

        self.save_hotkeys()

        self._handled_global_hotkeys.clear()


# ================================================================
# GLOBAL HOTKEY NORMALIZATION
# ================================================================

    def _hotkey_key_name(self, key):

        modifier = self._canonical_modifier(key)

        if modifier:
            return modifier

        try:

            if (
                hasattr(key, "char")
                and key.char is not None
            ):

                ch = key.char

                control_base = (
                    self._control_char_to_base(ch)
                )

                if control_base is not None:
                    return control_base.upper()

                if (
                    len(ch) == 1
                    and ord(ch) >= 32
                ):
                    return ch.upper()

        except Exception:
            pass

        mapped = self._keymap_special_lookup(key)

        if mapped is None:
            return None

        mapped = str(mapped)

        if mapped.lower().startswith("key."):
            mapped = mapped[4:]

        return mapped.upper()


    def _hotkey_base_from_key(self, key):

        if self._is_modifier_key(key):
            return None

        return self._hotkey_key_name(key)


    def build_hotkey_string_from_key(self, key):

        try:

            if (
                hasattr(key, "char")
                and key.char is not None
            ):

                control_base = (
                    self._control_char_to_base(
                        key.char
                    )
                )

                if control_base is not None:

                    parts = self._get_modifier_prefix()

                    if "Ctrl" not in parts:
                        parts.insert(0, "Ctrl")

                    parts.append(
                        control_base.upper()
                    )

                    return "+".join(parts)

        except Exception:
            pass

        base = self._hotkey_base_from_key(key)

        if base is None:
            return None

        base = str(base)

        if base.upper() in {
            "CTRL",
            "CTRL_L",
            "CTRL_R",
            "SHIFT",
            "SHIFT_L",
            "SHIFT_R",
            "ALT",
            "ALT_L",
            "ALT_R",
            "CMD",
            "CMD_L",
            "CMD_R"
        }:
            return None

        parts = self._get_modifier_prefix()

        parts.append(base)

        return "+".join(parts)


    def build_hotkey_string_from_mouse(self, button):

        parts = self._get_modifier_prefix()

        if button == Button.left:
            base = "MouseLeft"

        elif button == Button.right:
            base = "MouseRight"

        elif button == Button.middle:
            base = "MouseMiddle"

        elif button == Button.x1:
            base = "MouseButton4"

        elif button == Button.x2:
            base = "MouseButton5"

        else:
            base = "MouseUnknown"

        parts.append(base)

        return "+".join(parts)


# ================================================================
# HOTKEY DEBOUNCE
# ================================================================

    def _hotkey_already_handled(self, hotkey_str):

        if not hotkey_str:
            return True

        if not hasattr(
            self,
            "_handled_global_hotkeys"
        ):
            self._handled_global_hotkeys = set()

        if hotkey_str in self._handled_global_hotkeys:
            return True

        self._handled_global_hotkeys.add(
            hotkey_str
        )

        return False


    def _release_hotkey_key(self, key):

        if not hasattr(
            self,
            "_handled_global_hotkeys"
        ):
            return

        raw_names = set()

        try:

            base = self._hotkey_key_name(key)

            if base:
                raw_names.add(
                    str(base).upper()
                )

                raw_names.add(
                    str(base)
                )

        except Exception:
            pass

        raw = str(key).replace(
            "Key.",
            ""
        ).upper()

        raw_names.add(raw)

        for item in list(
            self._handled_global_hotkeys
        ):

            upper_item = item.upper()

            for raw_name in raw_names:

                if (
                    upper_item == raw_name
                    or upper_item.endswith(
                        "+" + raw_name
                    )
                ):

                    self._handled_global_hotkeys.discard(
                        item
                    )

                    break


# ================================================================
# GLOBAL KEY LISTENERS
# ================================================================

    def global_on_key_press(self, key):

        self._set_modifier_state(
            key,
            True
        )

        # IMPORTANT:
        # There is deliberately NO special
        # "if self.playing_back" interception here.
        #
        # Playback-generated keys are allowed to reach the
        # ordinary global hotkey handler exactly as requested.
        #
        # This restores the original/simple behavior and avoids
        # the playback hotkey being swallowed by playback state.

        if self._is_modifier_key(key):
            return

        hotkey_str = (
            self.build_hotkey_string_from_key(key)
        )

        if not hotkey_str:
            return

        if self._hotkey_already_handled(
            hotkey_str
        ):
            return

        if (
            self.assigning_record_hotkey
            or self.assigning_play_hotkey
        ):
            self.finalize_hotkey(
                hotkey_str
            )
            return

        if hotkey_str == self.record_hotkey:

            self.toggle_recording()
            return

        if hotkey_str == self.play_hotkey:

            if self.playing_back:
                self.stop_playback()

            else:
                self.start_playback()


    def global_on_key_release(self, key):

        self._release_hotkey_key(key)

        self._set_modifier_state(
            key,
            False
        )


    def global_on_click(
        self,
        x,
        y,
        button,
        pressed
    ):

        if not pressed:
            return

        hotkey_str = (
            self.build_hotkey_string_from_mouse(
                button
            )
        )

        if not hotkey_str:
            return

        if (
            self.assigning_record_hotkey
            or self.assigning_play_hotkey
        ):
            self.finalize_hotkey(
                hotkey_str
            )
            return

        if self._hotkey_already_handled(
            hotkey_str
        ):
            return

        if hotkey_str == self.record_hotkey:

            self.toggle_recording()

        elif hotkey_str == self.play_hotkey:

            if self.playing_back:
                self.stop_playback()

            else:
                self.start_playback()


# ================================================================
# RECORDING HOTKEY FILTER
# ================================================================

    def is_hotkey_key(self, key):

        hotkey_str = (
            self.build_hotkey_string_from_key(
                key
            )
        )

        if not hotkey_str:
            return False

        return (
            hotkey_str == self.record_hotkey
            or hotkey_str == self.play_hotkey
        )


    def is_hotkey_mouse(self, button):

        hotkey_str = (
            self.build_hotkey_string_from_mouse(
                button
            )
        )

        return (
            hotkey_str == self.record_hotkey
            or hotkey_str == self.play_hotkey
        )


# ================================================================
# MAIN
# ================================================================

if __name__ == "__main__":

    root = tk.Tk()

    root.title("Macro Recorder")

    app = MacroRecorder(root)

    app.pack(
        fill="both",
        expand=True
    )

    root.mainloop()
