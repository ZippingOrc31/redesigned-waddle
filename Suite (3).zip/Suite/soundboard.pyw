import os
import subprocess
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
import tempfile

import numpy as np
import sounddevice as sd
import soundfile as sf

DEFAULT_SR = 48000
DEFAULT_CH = 2

PLAYBACK_DEVICE = None
FFMPEG_PATH = None
AUDIO_DEVICES = []

# ---------------------------------------------------------
# Themes
# ---------------------------------------------------------
THEME_DARK = {
    "bg": "#1C1C1C",
    "fg": "#F0F0F0",
    "accent": "#FF8C00",
    "list_bg": "#2A2A2A",
    "list_fg": "#F0F0F0",
    "status_bg": "#111111",
    "status_fg": "#FF8C00",
}

THEME_LIGHT = {
    "bg": "#F0F0F0",
    "fg": "#000000",
    "accent": "#FF8C00",
    "list_bg": "#FFFFFF",
    "list_fg": "#000000",
    "status_bg": "#DDDDDD",
    "status_fg": "#000000",
}

current_theme = "dark"

# ---------------------------------------------------------
# FFmpeg Handling
# ---------------------------------------------------------
def ensure_ffmpeg():
    if not FFMPEG_PATH or not os.path.isfile(FFMPEG_PATH):
        messagebox.showerror("FFmpeg Missing", "Please set FFmpeg path first.")
        return False
    return True

# ---------------------------------------------------------
# Audio Clip
# ---------------------------------------------------------
class AudioClip:
    def __init__(self, name, data, samplerate):
        self.name = name
        self.data = data.astype("float32")
        self.samplerate = samplerate

    @staticmethod
    def load_any(path):
        ext = os.path.splitext(path)[1].lower()

        # Direct formats
        if ext in [".wav", ".flac", ".ogg"]:
            data, sr = sf.read(path, dtype="float32")
            if data.ndim == 1:
                data = np.stack([data, data], axis=1)
            return AudioClip(os.path.basename(path), data, sr)

        # FFmpeg conversion
        if not ensure_ffmpeg():
            raise RuntimeError("FFmpeg not available")

        temp_wav = os.path.join(tempfile.gettempdir(), "sb_temp.wav")

        try:
            cmd = [
                FFMPEG_PATH,
                "-y",
                "-i", os.path.abspath(path),
                "-ar", str(DEFAULT_SR),
                "-ac", str(DEFAULT_CH),
                temp_wav
            ]

            result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

            if result.returncode != 0:
                raise RuntimeError(f"FFmpeg error:\n{result.stderr}")

            data, sr = sf.read(temp_wav, dtype="float32")
            return AudioClip(os.path.basename(path), data, sr)

        finally:
            if os.path.exists(temp_wav):
                try: os.remove(temp_wav)
                except: pass

    @staticmethod
    def record(name, duration):
        frames = int(duration * DEFAULT_SR)
        data = sd.rec(frames, samplerate=DEFAULT_SR, channels=DEFAULT_CH, dtype="float32")
        sd.wait()
        return AudioClip(name, data, DEFAULT_SR)

    def save_wav(self, path):
        sf.write(path, self.data, self.samplerate)

# ---------------------------------------------------------
# Playback Engine
# ---------------------------------------------------------
class PlaybackEngine:
    def __init__(self):
        self.stop_flag = threading.Event()
        self.thread = None

    def play(self, clip, device):
        self.stop()
        self.stop_flag.clear()
        self.thread = threading.Thread(target=self._worker, args=(clip, device), daemon=True)
        self.thread.start()

    def _worker(self, clip, device):
        try:
            info = sd.query_devices(device, 'output')
            out_channels = info['max_output_channels']
        except:
            out_channels = clip.data.shape[1]

        data = clip.data

        if out_channels == 1:
            data = data.mean(axis=1, keepdims=True)

        idx = 0

        def callback(outdata, frames, time, status):
            nonlocal idx
            end = idx + frames
            if end >= len(data):
                chunk = data[idx:]
                outdata[:len(chunk)] = chunk
                outdata[len(chunk):] = 0
                self.stop_flag.set()
                raise sd.CallbackStop()
            else:
                outdata[:] = data[idx:end]
                idx = end

        try:
            with sd.OutputStream(
                samplerate=clip.samplerate,
                channels=data.shape[1],
                device=device,
                dtype="float32",
                callback=callback
            ):
                while not self.stop_flag.is_set():
                    sd.sleep(50)
        except Exception as e:
            print("Playback error:", e)

    def stop(self):
        self.stop_flag.set()

# ---------------------------------------------------------
# GUI
# ---------------------------------------------------------
class SoundboardApp(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)

        # Make this frame act as the root for all internal widgets
        self.root = self

        self.clips = []
        self.playback = PlaybackEngine()
        self.widgets = []

        self._ui()
        self.apply_theme()


    # -----------------------------------------------------
    # Device dropdown
    # -----------------------------------------------------
    def refresh_device_list(self):
        global AUDIO_DEVICES
        AUDIO_DEVICES = []
        devices = sd.query_devices()

        for i, d in enumerate(devices):
            name = d['name'].lower()

            # Voicemeeter virtual playback inputs
            if "voicemeeter vaio" in name or "voicemeeter aux" in name or "voicemeeter vaio3" in name:
                AUDIO_DEVICES.append(f"{i}: {d['name']}  [VM-IN]")
                continue

            # Normal playback devices
            if d['max_output_channels'] > 0:
                AUDIO_DEVICES.append(f"{i}: {d['name']}")
                continue

        if not AUDIO_DEVICES:
            AUDIO_DEVICES.append("No playback devices found")

        menu = self.device_dropdown["menu"]
        menu.delete(0, "end")

        for dev in AUDIO_DEVICES:
            menu.add_command(label=dev, command=lambda value=dev: self.device_var.set(value))

        self.device_var.set(AUDIO_DEVICES[0])

    # -----------------------------------------------------
    # UI
    # -----------------------------------------------------
    def _ui(self):
        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        left_frame = tk.Frame(self.main_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        lbl_clips = tk.Label(left_frame, text="Clips")
        lbl_clips.pack(anchor="w", pady=(0, 4))
        self.widgets.append(lbl_clips)

        self.listbox = tk.Listbox(left_frame, height=14)
        self.listbox.pack(fill=tk.BOTH, expand=True)
        self.widgets.append(self.listbox)

        right_frame = tk.Frame(self.main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=(8, 0))

        # Device dropdown
        self.device_var = tk.StringVar()
        self.device_dropdown = tk.OptionMenu(right_frame, self.device_var, "")
        self.device_dropdown.pack(fill=tk.X, pady=2)
        self.widgets.append(self.device_dropdown)

        self.refresh_device_list()

        # Buttons
        btn_import = tk.Button(right_frame, text="Import Audio", command=self.import_audio)
        btn_record = tk.Button(right_frame, text="Record Clip", command=self.record_clip)
        btn_play = tk.Button(right_frame, text="Play", command=self.play_selected)
        btn_stop = tk.Button(right_frame, text="Stop", command=self.stop_playback)
        btn_save = tk.Button(right_frame, text="Save Clip As WAV", command=self.save_selected)
        btn_set_dev = tk.Button(right_frame, text="Set Playback Device", command=self.set_play_device)
        btn_set_ffmpeg = tk.Button(right_frame, text="Set FFmpeg Path", command=self.set_ffmpeg_path)
        btn_theme = tk.Button(right_frame, text="Toggle Dark/Light Mode", command=self.toggle_theme)

        for b in [btn_import, btn_record, btn_play, btn_stop, btn_save, btn_set_dev, btn_set_ffmpeg, btn_theme]:
            b.pack(fill=tk.X, pady=2)
            self.widgets.append(b)

        info_frame = tk.Frame(self.root)
        info_frame.pack(fill=tk.X, padx=8, pady=(0, 4))

        self.lbl_device = tk.Label(info_frame, text="Playback Device: None")
        self.lbl_clip_info = tk.Label(info_frame, text="Clip: None")
        self.widgets.extend([self.lbl_device, self.lbl_clip_info])

        self.lbl_device.pack(side=tk.LEFT, padx=(0, 8))
        self.lbl_clip_info.pack(side=tk.LEFT)

        self.status_bar = tk.Label(self.root, text="Ready", anchor="w")
        self.status_bar.pack(fill=tk.X, side=tk.BOTTOM)
        self.widgets.append(self.status_bar)

    # -----------------------------------------------------
    # Theme
    # -----------------------------------------------------
    def apply_theme(self):
        theme = THEME_DARK if current_theme == "dark" else THEME_LIGHT

        self.root.configure(bg=theme["bg"])
        self.main_frame.configure(bg=theme["bg"])

        for w in self.widgets:
            if isinstance(w, tk.Button):
                w.configure(
                    bg=theme["bg"], fg=theme["fg"],
                    activebackground=theme["accent"],
                    activeforeground=theme["fg"],
                    relief=tk.GROOVE, bd=1
                )
            elif isinstance(w, tk.Label):
                w.configure(bg=theme["bg"], fg=theme["fg"])
            elif isinstance(w, tk.Listbox):
                w.configure(
                    bg=theme["list_bg"], fg=theme["list_fg"],
                    selectbackground=theme["accent"],
                    selectforeground=theme["fg"]
                )

        self.status_bar.configure(bg=theme["status_bg"], fg=theme["status_fg"])

    def toggle_theme(self):
        global current_theme
        current_theme = "light" if current_theme == "dark" else "dark"
        self.apply_theme()
        self.set_status(f"Theme: {current_theme.capitalize()}")

    def set_status(self, msg):
        self.status_bar.config(text=msg)

    # -----------------------------------------------------
    # Core functionality
    # -----------------------------------------------------
    def import_audio(self):
        path = filedialog.askopenfilename(
            title="Import audio",
            filetypes=[("Audio", "*.wav *.flac *.ogg *.mp3 *.m4a *.aac *.wma"), ("All", "*.*")]
        )
        if not path:
            return

        try:
            clip = AudioClip.load_any(path)
            self.clips.append(clip)
            self.listbox.insert(tk.END, clip.name)
            self.set_status(f"Imported: {clip.name}")
        except Exception as e:
            messagebox.showerror("Import error", str(e))
            self.set_status("Import error")

    def record_clip(self):
        name = simpledialog.askstring("Clip name", "Name:")
        if not name:
            return

        dur = simpledialog.askfloat("Duration", "Seconds:", minvalue=0.5, maxvalue=600)
        if not dur:
            return

        try:
            clip = AudioClip.record(name, dur)
            self.clips.append(clip)
            self.listbox.insert(tk.END, clip.name)
            self.set_status(f"Recorded: {clip.name} ({dur:.1f}s)")
        except Exception as e:
            messagebox.showerror("Record error", str(e))
            self.set_status("Record error")

    def get_selected(self):
        sel = self.listbox.curselection()
        if not sel:
            return None
        clip = self.clips[sel[0]]
        duration = len(clip.data) / clip.samplerate
        channels = clip.data.shape[1]
        self.lbl_clip_info.config(
            text=f"Clip: {clip.name} | {duration:.2f}s | {channels}ch @ {clip.samplerate} Hz"
        )
        return clip

    def play_selected(self):
        clip = self.get_selected()
        if not clip:
            messagebox.showinfo("No selection", "Pick a clip first.")
            self.set_status("No clip selected")
            return
        self.playback.play(clip, PLAYBACK_DEVICE)
        self.set_status(f"Playing: {clip.name}")

    def stop_playback(self):
        self.playback.stop()
        self.set_status("Playback stopped")

    def save_selected(self):
        clip = self.get_selected()
        if not clip:
            return
        path = filedialog.asksaveasfilename(defaultextension=".wav")
        if path:
            clip.save_wav(path)
            self.set_status(f"Saved: {path}")

    def set_play_device(self):
        global PLAYBACK_DEVICE
        selected = self.device_var.get()
        if ":" in selected:
            PLAYBACK_DEVICE = int(selected.split(":")[0])
        else:
            PLAYBACK_DEVICE = None

        self.lbl_device.config(text=f"Playback Device: {selected}")
        self.set_status(f"Playback device set: {selected}")

    def set_ffmpeg_path(self):
        global FFMPEG_PATH
        path = filedialog.askopenfilename(
            title="Select ffmpeg.exe",
            filetypes=[("Executable", "*.exe")]
        )
        if path:
            FFMPEG_PATH = path
            messagebox.showinfo("FFmpeg Set", f"FFmpeg path saved:\n{FFMPEG_PATH}")
            self.set_status("FFmpeg path updated")
