#!/usr/bin/env python3
"""
Launcher (final regen)
- Scrollbars hidden (not packed) while canvas remains scrollable via mouse wheel and programmatic scrolling
- Resize chunk made larger and lifted so it's reliably grabbable
- Window + / - buttons perform real geometry resize (no scaling)
- Keeps theme customizer, scale controls, layout persistence
- Uses global instances for toggled widgets
"""

import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox
import json
import os

# Replace these imports with your actual modules
from rapdi import MacroRecorder
from controllerclicker import ControllerClicker
from mouseclicker import MouseClicker
from soundboard import SoundboardApp

LAYOUT_FILE = "theme_and_layout.json"
EXTERNAL_PRESETS_FILE = "theme.json"

DEFAULT_LAYOUT = {
    "current": {"background": "#d0d0d0", "topbar": "#c0c0c0", "text": "#000000", "accent": "#909090"},
    "presets": {
        "Dark": {"background": "#1e1e1e", "topbar": "#2a2a2a", "text": "#ffffff", "accent": "#444444"},
        "Neon": {"background": "#0f0f0f", "topbar": "#1a1a1a", "text": "#00ffea", "accent": "#ff00c8"}
    },
    "layout": {"geometry": None, "sash_fraction": 0.9, "content_scale": 0.5}
}


def load_layout_file(path=LAYOUT_FILE):
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            for k in ("current", "presets", "layout"):
                if k not in data:
                    data[k] = DEFAULT_LAYOUT[k]
            return data
        except Exception:
            return DEFAULT_LAYOUT.copy()
    return DEFAULT_LAYOUT.copy()


def save_layout_file(data, path=LAYOUT_FILE):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return True
    except Exception:
        return False


def load_external_presets(path=EXTERNAL_PRESETS_FILE):
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data.get("presets", data)
        except Exception:
            pass
    return {}


# -------------------------
# Main launcher
# -------------------------
def main():
    global controller_instance, mouse_instance, soundboard_instance

    controller_instance = None
    mouse_instance = None
    soundboard_instance = None

    theme_layout = load_layout_file()
    theme_layout.setdefault("presets", {}).update(load_external_presets())

    root = tk.Tk()
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    root.attributes("-alpha", 0.92)

    # Restore geometry or default
    saved_geom = theme_layout.get("layout", {}).get("geometry")
    if saved_geom:
        try:
            root.geometry(saved_geom)
        except Exception:
            pass
    else:
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        default_w, default_h = max(700, int(sw * 0.5)), max(420, int(sh * 0.5))
        root.geometry(f"{default_w}x{default_h}+{(sw-default_w)//2}+{(sh-default_h)//2}")

    # ---------- helpers ----------
    def apply_theme(colors):
        root.configure(bg=colors["background"])
        main_frame.configure(bg=colors["background"])
        tools_frame.configure(bg=colors["background"])
        try:
            macro_inner.configure(bg=colors["background"])
            if macro_panel is not None:
                macro_panel.configure(bg=colors["background"])
        except Exception:
            pass
        top_bar.configure(bg=colors["topbar"])
        file_button.configure(bg=colors["topbar"], fg=colors["text"])
        exit_btn.configure(bg=colors["topbar"], fg=colors["text"])
        resize_handle.configure(bg=colors["accent"])
        theme_layout["current"].update(colors)

    def set_sash_fraction(frac):
        total_w = root.winfo_width()
        if total_w <= 0:
            return
        sash_pos = int(total_w * float(frac))
        sash_pos = max(100, min(total_w - 100, sash_pos))
        try:
            paned.sashpos(0, sash_pos)
        except Exception:
            try:
                paned.sashpos(0, sash_pos)
            except Exception:
                pass
        theme_layout.setdefault("layout", {})["sash_fraction"] = float(frac)

    # ---------- top bar ----------
    top_bar = tk.Frame(root, bg=theme_layout["current"].get("topbar", "#c0c0c0"), height=30)
    top_bar.pack(fill="x")

    def start_drag(e):
        root._dx, root._dy = e.x, e.y

    def do_drag(e):
        root.geometry(f"+{root.winfo_x() + e.x - root._dx}+{root.winfo_y() + e.y - root._dy}")

    top_bar.bind("<ButtonPress-1>", start_drag)
    top_bar.bind("<B1-Motion>", do_drag)

    file_menu = tk.Menu(root, tearoff=0)

    def open_color_customizer():
        win = tk.Toplevel(root)
        win.title("Color Customizer")
        win.geometry("360x420")
        win.configure(bg="#222222")
        selected = dict(theme_layout.get("current", DEFAULT_LAYOUT["current"]).copy())

        tk.Label(win, text="Color Customizer", fg="white", bg="#222222", font=("Arial", 14, "bold")).pack(pady=8)

        def picker(label, key):
            f = tk.Frame(win, bg="#222222"); f.pack(fill="x", padx=12, pady=6)
            tk.Label(f, text=label, fg="white", bg="#222222").pack(side="left")
            tk.Button(f, text="Pick", command=lambda k=key: pick(k)).pack(side="right")

        def pick(key):
            c = colorchooser.askcolor()[1]
            if c:
                selected[key] = c
                apply_theme(selected)

        picker("Background Color", "background")
        picker("Top Bar Color", "topbar")
        picker("Text Color", "text")
        picker("Accent / Resize Handle", "accent")

        tk.Label(win, text="Presets", fg="white", bg="#222222").pack(pady=6)
        pf = tk.Frame(win, bg="#222222"); pf.pack(fill="x", padx=12)
        names = list(theme_layout.get("presets", {}).keys())
        preset_var = tk.StringVar(value=names[0] if names else "")
        om = tk.OptionMenu(pf, preset_var, *names); om.configure(bg="#333333", fg="white"); om.pack(side="left", fill="x", expand=True)

        def apply_preset():
            n = preset_var.get()
            if n:
                selected.update(theme_layout["presets"][n])
                apply_theme(selected)

        tk.Button(pf, text="Apply", command=apply_preset).pack(side="right", padx=6)
        tk.Button(win, text="Apply Theme", width=20, command=lambda: apply_theme(selected)).pack(pady=8)

        def save_theme():
            p = filedialog.asksaveasfilename(defaultextension=".theme", filetypes=[("Theme", "*.theme"), ("JSON", "*.json")])
            if not p: return
            try:
                with open(p, "w", encoding="utf-8") as f:
                    json.dump(selected, f, indent=2)
                messagebox.showinfo("Saved", "Theme saved")
            except Exception as e:
                messagebox.showerror("Error", str(e))

        def load_theme():
            p = filedialog.askopenfilename(filetypes=[("Theme", "*.theme"), ("JSON", "*.json")])
            if not p: return
            try:
                with open(p, "r", encoding="utf-8") as f:
                    d = json.load(f)
                selected.update(d); apply_theme(selected)
            except Exception:
                messagebox.showerror("Error", "Invalid theme file")

        tk.Button(win, text="Save Theme", width=20, command=save_theme).pack(pady=4)
        tk.Button(win, text="Load Theme", width=20, command=load_theme).pack(pady=4)

        def import_external():
            p = filedialog.askopenfilename(filetypes=[("JSON", "*.json"), ("All", "*.*")])
            if not p: return
            try:
                with open(p, "r", encoding="utf-8") as f:
                    d = json.load(f)
                new = d.get("presets", d) if isinstance(d, dict) else {}
                for k, v in new.items():
                    theme_layout.setdefault("presets", {})[k] = v
                names = list(theme_layout.get("presets", {}).keys())
                preset_var.set(names[0] if names else "")
                om["menu"].delete(0, "end")
                for name in names:
                    om["menu"].add_command(label=name, command=lambda n=name: preset_var.set(n))
                messagebox.showinfo("Imported", "Presets imported")
            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(win, text="Import Presets (theme.json)", width=28, command=import_external).pack(pady=6)

    file_menu.add_command(label="Color Customize", command=open_color_customizer)
    file_menu.add_separator()

    def save_layout_cmd():
        try:
            theme_layout.setdefault("layout", {})["geometry"] = root.geometry()
            s = paned.sashpos(0); tw = root.winfo_width()
            if tw > 0:
                theme_layout["layout"]["sash_fraction"] = s / tw
            theme_layout["layout"]["content_scale"] = current_scale
        except Exception:
            pass
        save_layout_file(theme_layout)
        messagebox.showinfo("Saved", "Layout saved")

    def load_layout_cmd():
        p = filedialog.askopenfilename(filetypes=[("JSON", "*.json"), ("All", "*.*")])
        if not p: return
        try:
            with open(p, "r", encoding="utf-8") as f:
                d = json.load(f)
            for k in ("current", "presets", "layout"):
                if k in d:
                    theme_layout[k] = d[k]
            apply_theme(theme_layout["current"])
            root.update_idletasks(); restore_sash()
            cs = float(theme_layout.get("layout", {}).get("content_scale", current_scale))
            set_scale(cs)
            messagebox.showinfo("Loaded", "Layout loaded")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    file_menu.add_command(label="Save Layout", command=save_layout_cmd)
    file_menu.add_command(label="Load Layout", command=load_layout_cmd)
    file_menu.add_separator()
    file_menu.add_command(label="Exit", command=root.destroy)

    file_button = tk.Button(top_bar, text="File ▼", bg=theme_layout["current"]["topbar"], relief="flat",
                            command=lambda: file_menu.tk_popup(file_button.winfo_rootx(),
                                                              file_button.winfo_rooty() + file_button.winfo_height()))
    file_button.pack(side="left", padx=6)

    exit_btn = tk.Button(top_bar, text="❌", bg=theme_layout["current"]["topbar"],
                         fg=theme_layout["current"]["text"], relief="flat", command=root.destroy)
    exit_btn.pack(side="right", padx=6)

    # ---------- main area ----------
    main_frame = tk.Frame(root, bg=theme_layout["current"]["background"])
    main_frame.pack(fill="both", expand=True)

    paned = tk.PanedWindow(main_frame, orient=tk.HORIZONTAL)
    paned.pack(fill="both", expand=True)

    # Macro area (canvas). Scrollbars are created but NOT packed so they are invisible.
    macro_container = tk.Frame(paned, bg=theme_layout["current"]["background"])
    macro_canvas = tk.Canvas(macro_container, highlightthickness=0)
    v_scroll = tk.Scrollbar(macro_container, orient="vertical", command=macro_canvas.yview)
    h_scroll = tk.Scrollbar(macro_container, orient="horizontal", command=macro_canvas.xview)
    macro_canvas.configure(yscrollcommand=v_scroll.set, xscrollcommand=h_scroll.set)
    # Do NOT pack v_scroll/h_scroll to keep them invisible; mouse wheel will handle scrolling
    macro_canvas.pack(side="left", fill="both", expand=True)

    macro_inner = tk.Frame(macro_canvas, bg=theme_layout["current"]["background"])
    inner_id = macro_canvas.create_window((0, 0), window=macro_inner, anchor="nw")

    # instantiate MacroRecorder inside macro_inner (try both parent styles)
    try:
        macro_panel = MacroRecorder(macro_inner)
    except Exception:
        macro_panel = MacroRecorder(macro_container)
    macro_panel.pack(fill="both", expand=True, padx=8, pady=8)

    def on_inner_configure(event):
        macro_canvas.configure(scrollregion=macro_canvas.bbox("all"))
        inner_w = event.width
        canvas_w = macro_canvas.winfo_width()
        if inner_w != canvas_w:
            macro_canvas.itemconfigure(inner_id, width=canvas_w)

    macro_inner.bind("<Configure>", on_inner_configure)

    def on_canvas_configure(event):
        try:
            macro_canvas.itemconfigure(inner_id, width=event.width)
        except Exception:
            pass

    macro_canvas.bind("<Configure>", on_canvas_configure)

    # Mouse wheel scrolling only when cursor over canvas
    def wheel_windows(event):
        # event.delta positive = scroll up
        macro_canvas.yview_scroll(-1 if event.delta > 0 else 1, "units")

    def wheel_unix(event):
        macro_canvas.yview_scroll(-1 if event.num == 4 else 1, "units")

    def bind_wheel(e):
        macro_canvas.bind_all("<MouseWheel>", wheel_windows)
        macro_canvas.bind_all("<Button-4>", wheel_unix)
        macro_canvas.bind_all("<Button-5>", wheel_unix)

    def unbind_wheel(e):
        try:
            macro_canvas.unbind_all("<MouseWheel>")
            macro_canvas.unbind_all("<Button-4>")
            macro_canvas.unbind_all("<Button-5>")
        except Exception:
            pass

    macro_canvas.bind("<Enter>", bind_wheel)
    macro_canvas.bind("<Leave>", unbind_wheel)

    # ---------- tools sidebar ----------
    tools_frame = tk.Frame(paned, bg=theme_layout["current"]["background"])
    buttons_frame = tk.Frame(tools_frame, bg=theme_layout["current"]["background"])
    buttons_frame.pack(side="top", fill="y", padx=6, pady=8)
    tools_content = tk.Frame(tools_frame, bg=theme_layout["current"]["background"])
    tools_content.pack(side="bottom", fill="both", expand=True, padx=6, pady=6)

    paned.add(macro_container, stretch="always")
    paned.add(tools_frame)
    try:
        paned.paneconfig(macro_container, minsize=200)
        paned.paneconfig(tools_frame, minsize=80)
    except Exception:
        pass

    # ---------- toggles ----------
    def toggle_controller():
        global controller_instance
        if controller_instance is None:
            controller_instance = ControllerClicker(tools_content)
            controller_instance.pack(fill="both", expand=True, pady=6)
        else:
            try:
                controller_instance.stop_thread()
            except Exception:
                pass
            controller_instance.destroy()
            controller_instance = None

    def toggle_mouse():
        global mouse_instance
        if mouse_instance is None:
            mouse_instance = MouseClicker(tools_content)
            mouse_instance.pack(fill="both", expand=True, pady=6)
        else:
            try:
                mouse_instance.stop_thread()
            except Exception:
                pass
            mouse_instance.destroy()
            mouse_instance = None

    def toggle_soundboard():
        global soundboard_instance
        if soundboard_instance is None:
            soundboard_instance = SoundboardApp(tools_content)
            soundboard_instance.pack(fill="both", expand=True, pady=6)
        else:
            try:
                soundboard_instance.destroy()
            except Exception:
                pass
            soundboard_instance = None


    # Build button grid
    grid_cols = 2
    btn_specs = [
        ("Controller Clicker", toggle_controller),
        ("Mouse Clicker", toggle_mouse),
        ("Soundboard", toggle_soundboard),
    ]
    for idx, (label, cmd) in enumerate(btn_specs):
        r = idx // grid_cols
        c = idx % grid_cols
        b = tk.Button(buttons_frame, text=label, width=14, command=cmd)
        b.grid(row=r, column=c, padx=4, pady=4, sticky="ew")
        buttons_frame.grid_columnconfigure(c, weight=1)

    # ---------- scale controls ----------
    current_scale = float(theme_layout.get("layout", {}).get("content_scale", 0.5))

    def apply_canvas_scale(factor):
        try:
            macro_canvas.scale("all", 0, 0, factor, factor)
            macro_canvas.configure(scrollregion=macro_canvas.bbox("all"))
            macro_canvas.update_idletasks()
        except Exception:
            pass

    def set_scale(new_scale):
        nonlocal current_scale
        if new_scale <= 0.1:
            new_scale = 0.1
        factor = new_scale / current_scale
        apply_canvas_scale(factor)
        try:
            root.tk.call('tk', 'scaling', new_scale)
        except Exception:
            pass
        current_scale = new_scale
        theme_layout.setdefault("layout", {})["content_scale"] = current_scale

    def scale_down():
        set_scale(round(current_scale * 0.9, 3))

    def scale_up():
        set_scale(round(current_scale * 1.1, 3))

    scale_frame = tk.Frame(tools_frame, bg=theme_layout["current"].get("background"))
    scale_frame.pack(side="bottom", pady=6)
    tk.Button(scale_frame, text="Scale -", width=8, command=scale_down).pack(side="left", padx=4)
    tk.Button(scale_frame, text="Scale +", width=8, command=scale_up).pack(side="left", padx=4)

    # ---------- window resize controls (real geometry resize) ----------
    def resize_window_by_percent(delta_percent):
        try:
            w = root.winfo_width()
            h = root.winfo_height()
            new_w = max(300, int(w * (1.0 + delta_percent)))
            new_h = max(200, int(h * (1.0 + delta_percent)))
            x = root.winfo_x()
            y = root.winfo_y()
            root.geometry(f"{new_w}x{new_h}+{x}+{y}")
            root.update_idletasks()
            try:
                sash_pos = paned.sashpos(0)
                total_w = root.winfo_width()
                if total_w > 0:
                    theme_layout.setdefault("layout", {})["sash_fraction"] = sash_pos / total_w
            except Exception:
                pass
        except Exception:
            pass

    def window_increase():
        resize_window_by_percent(0.10)

    def window_decrease():
        resize_window_by_percent(-0.10)

    resize_frame = tk.Frame(tools_frame, bg=theme_layout["current"].get("background"))
    resize_frame.pack(side="bottom", pady=6)
    tk.Button(resize_frame, text="Window -", width=8, command=window_decrease).pack(side="left", padx=4)
    tk.Button(resize_frame, text="Window +", width=8, command=window_increase).pack(side="left", padx=4)

    # ---------- resize handle (larger and lifted so it's grabbable) ----------
    resize_handle = tk.Frame(root, bg=theme_layout["current"].get("accent", "#909090"),
                             cursor="size_nw_se", height=20, width=20, bd=0, relief="flat")
    # place slightly inset so it's always clickable and above other widgets
    resize_handle.place(relx=1.0, rely=1.0, x=-6, y=-6, anchor="se")
    resize_handle.lift()

    def start_resize(event):
        # record absolute pointer position relative to root
        root._resize_start_x = root.winfo_pointerx()
        root._resize_start_y = root.winfo_pointery()
        root._start_width = root.winfo_width()
        root._start_height = root.winfo_height()

    def do_resize(event):
        # compute delta using absolute pointer coords for smoother dragging
        try:
            px = root.winfo_pointerx()
            py = root.winfo_pointery()
            dx = px - root._resize_start_x
            dy = py - root._resize_start_y
            new_w = max(300, root._start_width + dx)
            new_h = max(200, root._start_height + dy)
            root.geometry(f"{new_w}x{new_h}")
            root.update_idletasks()
            try:
                sash_pos = paned.sashpos(0)
                total_w = root.winfo_width()
                if total_w > 0:
                    theme_layout.setdefault("layout", {})["sash_fraction"] = sash_pos / total_w
            except Exception:
                pass
        except Exception:
            pass

    # Bind both to the handle and to the root so dragging remains responsive
    resize_handle.bind("<ButtonPress-1>", start_resize)
    resize_handle.bind("<B1-Motion>", do_resize)
    root.bind("<ButtonPress-1>", lambda e: None)  # keep root responsive
    resize_handle.lift()

    # ---------- layout helpers ----------
    def restore_sash():
        frac = float(theme_layout.get("layout", {}).get("sash_fraction", 0.9))
        root.update_idletasks()
        set_sash_fraction(frac)
        try:
            total_w = root.winfo_width()
            if total_w > 0:
                sidebar_w = max(80, int(total_w * 0.10))
                tools_frame.update_idletasks()
                tools_frame.config(width=sidebar_w)
        except Exception:
            pass

    def on_map(event):
        restore_sash()
        # apply saved scale
        saved = float(theme_layout.get("layout", {}).get("content_scale", current_scale))
        try:
            root.tk.call('tk', 'scaling', saved)
        except Exception:
            pass
        try:
            apply_canvas_scale(saved / current_scale)
        except Exception:
            pass

    root.bind("<Map>", on_map)

    def on_configure(event):
        try:
            resize_handle.place(relx=1.0, rely=1.0, x=-6, y=-6, anchor="se")
            resize_handle.lift()
        except Exception:
            pass
        try:
            total_w = root.winfo_width()
            if total_w > 0:
                sash_pos = paned.sashpos(0)
                theme_layout.setdefault("layout", {})["sash_fraction"] = sash_pos / total_w
                sidebar_w = max(80, int(total_w * 0.10))
                tools_frame.config(width=sidebar_w)
        except Exception:
            pass

    root.bind("<Configure>", on_configure)

    # ---------- apply theme and restore ----------
    apply_theme(theme_layout.get("current", DEFAULT_LAYOUT["current"]))
    root.after(80, restore_sash)

    # ---------- close ----------
    def on_close():
        try:
            theme_layout.setdefault("layout", {})["geometry"] = root.geometry()
            s = paned.sashpos(0); tw = root.winfo_width()
            if tw > 0:
                theme_layout["layout"]["sash_fraction"] = s / tw
            theme_layout["layout"]["content_scale"] = current_scale
        except Exception:
            pass
        save_layout_file(theme_layout)
        for inst in (controller_instance, mouse_instance, soundboard_instance):
            try:
                if inst is not None:
                    inst.stop_thread()
            except Exception:
                pass
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    root.bind("<Escape>", lambda e: on_close())

    root.mainloop()


if __name__ == "__main__":
    main()
