import tkinter as tk
import threading
import pyautogui
import time
import keyboard
import mouse
import ctypes
import sys

if sys.platform == "win32":
    ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)


class MouseClicker(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg="#e0e0e0")

        self.rapid_fire = False
        self.binding_active = False
        self.binding = ("keyboard", "space")

        tk.Label(self, text="Mouse / Keyboard Clicker",
                 fg="#303030", bg="#e0e0e0").pack(pady=3)

        tk.Label(self, text="Click Interval (seconds):",
                 fg="#303030", bg="#e0e0e0").pack(pady=5)
        self.interval_entry = tk.Entry(self)
        self.interval_entry.insert(0, "0.03")
        self.interval_entry.pack(pady=5)

        self.binding_label = tk.Label(self,
                                      text="Current Binding: keyboard [space]",
                                      fg="blue", bg="#e0e0e0")
        self.binding_label.pack(pady=5)

        self.bind_button = tk.Button(self, text="Bind Activation Key",
                                     command=self.start_binding)
        self.bind_button.pack(pady=5)

        self.status_label = tk.Label(self, text="Rapid: OFF",
                                     fg="red", bg="#e0e0e0")
        self.status_label.pack(pady=10)

        tk.Label(self, text="Event Log:",
                 fg="#303030", bg="#e0e0e0").pack()
        self.debug_box = tk.Text(self, height=6, width=40,
                                 bg="#202020", fg="lime")
        self.debug_box.pack(pady=5)

        tk.Label(self, text="Hold your bound key/button to rapid fire.",
                 fg="#303030", bg="#e0e0e0").pack(pady=5)

        threading.Thread(target=self.rapid_fire_loop, daemon=True).start()
        threading.Thread(target=self.activation_listener, daemon=True).start()

    def log(self, text):
        self.debug_box.insert(tk.END, text + "\n")
        self.debug_box.see(tk.END)

    def start_binding(self):
        self.binding_active = True
        self.binding_label.config(text="Press any key or mouse button...")
        self.log("Binding mode activated")

        def kb_handler(event):
            if self.binding_active and event.event_type == "down":
                self.finish_binding("keyboard", event.name)
                keyboard.unhook(kb_handler)

        keyboard.hook(kb_handler)

        def mouse_handler(event):
            if self.binding_active and hasattr(event, "button") and event.event_type == "down":
                self.finish_binding("mouse", str(event.button))
                mouse.unhook(mouse_handler)

        mouse.hook(mouse_handler)

    def finish_binding(self, btype, bval):
        self.binding = (btype, bval)
        self.binding_active = False
        self.binding_label.config(text=f"Current Binding: {btype} [{bval}]")
        self.log(f"Bound to: {btype} [{bval}]")

    def activation_listener(self):
        while True:
            btype, bval = self.binding

            if btype == "keyboard":
                if keyboard.is_pressed(bval):
                    self.enable_rapid()
                else:
                    self.disable_rapid()
            elif btype == "mouse":
                if mouse.is_pressed(bval):
                    self.enable_rapid()
                else:
                    self.disable_rapid()

            time.sleep(0.005)

    def rapid_fire_loop(self):
        while True:
            if self.rapid_fire:
                try:
                    interval = float(self.interval_entry.get())
                except ValueError:
                    interval = 0.03
                    self.interval_entry.delete(0, tk.END)
                    self.interval_entry.insert(0, "0.03")

                pyautogui.click()
                time.sleep(max(0.001, interval))
            else:
                time.sleep(0.001)

    def enable_rapid(self):
        if not self.rapid_fire:
            self.rapid_fire = True
            self.status_label.config(text="Rapid: ON", fg="green")

    def disable_rapid(self):
        if self.rapid_fire:
            self.rapid_fire = False
            self.status_label.config(text="Rapid: OFF", fg="red")
