import tkinter as tk
import threading
import pyautogui
import time
from inputs import get_gamepad
import ctypes
import sys

if sys.platform == "win32":
    ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)


class ControllerClicker(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg="#e0e0e0")

        self.running = True            # <-- ADDED shutdown flag
        self.rapid_fire = False
        self.interval = 1.0
        self.lt_val = 0

        tk.Label(self, text="Controller LT Clicker",
                 fg="#303030", bg="#e0e0e0").pack(pady=3)

        tk.Label(self, text="Click Interval (seconds):",
                 fg="#303030", bg="#e0e0e0").pack(pady=5)
        self.interval_entry = tk.Entry(self)
        self.interval_entry.insert(0, "0.03")
        self.interval_entry.pack(pady=5)

        self.lt_label = tk.Label(self, text="LT Axis: 0",
                                 fg="blue", bg="#e0e0e0")
        self.lt_label.pack(pady=5)

        tk.Label(self, text="Trigger Sensitivity Threshold",
                 fg="#303030", bg="#e0e0e0").pack(pady=5)
        self.threshold_slider = tk.Scale(self, from_=0, to=255,
                                         orient=tk.HORIZONTAL,
                                         bg="#e0e0e0", fg="#303030")
        self.threshold_slider.set(251)
        self.threshold_slider.pack(pady=5)

        self.status_label = tk.Label(self, text="Rapid: OFF",
                                     fg="red", bg="#e0e0e0")
        self.status_label.pack(pady=10)

        tk.Label(self, text="Hold LT to rapid fire.",
                 fg="#303030", bg="#e0e0e0").pack(pady=5)

        # Threads now respect self.running
        threading.Thread(target=self.listen_controller, daemon=True).start()
        threading.Thread(target=self.rapid_fire_loop, daemon=True).start()

    # -------------------------
    # SAFE SHUTDOWN METHOD
    # -------------------------
    def stop_thread(self):
        self.running = False

    # -------------------------
    # STATUS UPDATE
    # -------------------------
    def update_status(self):
        rapid = "ON" if self.rapid_fire else "OFF"
        self.status_label.config(text=f"Rapid: {rapid}",
                                 fg="green" if self.rapid_fire else "red")

    # -------------------------
    # RAPID FIRE LOOP
    # -------------------------
    def rapid_fire_loop(self):
        while self.running:   # <-- patched
            if self.rapid_fire:
                try:
                    self.interval = float(self.interval_entry.get())
                except (ValueError, tk.TclError):
                    self.interval = 1.0
                    try:
                        self.interval_entry.delete(0, tk.END)
                        self.interval_entry.insert(0, "1.0")
                    except tk.TclError:
                        break

                pyautogui.click()
                time.sleep(max(0.001, self.interval))
            else:
                time.sleep(0.01)

    # -------------------------
    # CONTROLLER LISTENER
    # -------------------------
    def listen_controller(self):
        while self.running:   # <-- patched
            try:
                events = get_gamepad()
            except Exception:
                break

            for event in events:
                try:
                    threshold = self.threshold_slider.get()
                except tk.TclError:
                    return  # widget destroyed → exit thread safely

                if event.code == "ABS_Z":
                    self.lt_val = event.state

                    try:
                        self.lt_label.config(text=f"LT Axis: {self.lt_val}")
                    except tk.TclError:
                        return

                    if self.lt_val > threshold:
                        if not self.rapid_fire:
                            self.rapid_fire = True
                            try:
                                self.update_status()
                            except tk.TclError:
                                return
                    else:
                        if self.rapid_fire:
                            self.rapid_fire = False
                            try:
                                self.update_status()
                            except tk.TclError:
                                return

            time.sleep(0)
