import tkinter as tk
from tkinter import simpledialog, messagebox
import threading
import time
import pynput
from pynput.keyboard import Listener as KeyListener, Key
from pynput.mouse import Listener as MouseListener, Button
from pynput.keyboard import Controller as KeyboardController
import sys
import ctypes
import os
import glob
import configparser

# Hide console window (Windows only)
if sys.platform == "win32":
    try:
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)
    except:
        pass

# -------------------------
# SENDINPUT STRUCTS
# -------------------------
class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", ctypes.c_long),
        ("dy", ctypes.c_long),
        ("mouseData", ctypes.c_ulong),
        ("dwFlags", ctypes.c_ulong),
        ("time", ctypes.c_ulong),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
    ]

class INPUT(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_ulong),
        ("mi", MOUSEINPUT),
    ]

SendInput = ctypes.windll.user32.SendInput

# Mouse flags
MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_ABSOLUTE = 0x8000
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_WHEEL = 0x0800

def send_mouse_move(dx, dy):
    inp = INPUT()
    inp.type = 0
    inp.mi = MOUSEINPUT(dx, dy, 0, MOUSEEVENTF_MOVE, 0, None)
    SendInput(1, ctypes.byref(inp), ctypes.sizeof(inp))

def send_mouse_move_absolute(x, y):
    user32 = ctypes.windll.user32
    screen_w = user32.GetSystemMetrics(0)
    screen_h = user32.GetSystemMetrics(1)

    abs_x = int(x * 65535 / (screen_w - 1))
    abs_y = int(y * 65535 / (screen_h - 1))

    inp = INPUT()
    inp.type = 0
    inp.mi = MOUSEINPUT(abs_x, abs_y, 0, MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE, 0, None)
    SendInput(1, ctypes.byref(inp), ctypes.sizeof(inp))

def send_mouse_click(button, down):
    inp = INPUT()
    inp.type = 0

    if button == "left":
        inp.mi.dwFlags = MOUSEEVENTF_LEFTDOWN if down else MOUSEEVENTF_LEFTUP
    else:
        inp.mi.dwFlags = MOUSEEVENTF_RIGHTDOWN if down else MOUSEEVENTF_RIGHTUP

    SendInput(1, ctypes.byref(inp), ctypes.sizeof(inp))

def send_mouse_scroll(amount):
    inp = INPUT()
    inp.type = 0
    inp.mi = MOUSEINPUT(0, 0, amount, MOUSEEVENTF_WHEEL, 0, None)
    SendInput(1, ctypes.byref(inp), ctypes.sizeof(inp))

# -------------------------
# MAIN APP CLASS
# -------------------------
class MacroRecorder(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg="black")
        self.parent = parent

        # State
        self.drag_enabled = True
        self.recording = False
        self.playing_back = False
        self.events = []
        self.start_time = 0

        # Playback settings
        self.playback_speed = 1.0
        self.loop_count = 1
        self.loop_infinite = False

        # Recording mode
        self.record_mode = tk.StringVar(value="relative")

        # Keyboard controller
        self.keyboard = KeyboardController()

        # Macro folder
        self.macro_folder = "macros"
        os.makedirs(self.macro_folder, exist_ok=True)

        # Hotkeys
        self.config_file = "hotkeys.cfg"
        self.record_hotkey = None
        self.play_hotkey = None
        self.load_hotkeys()

        # Modifier states
        self.mod_ctrl = False
        self.mod_shift = False
        self.mod_alt = False

        # -------------------------
        # GUI BUILD
        # -------------------------
        tk.Label(self, text="Macro Recorder + Manager", fg="white", bg="black").pack(pady=5)

        # Playback speed + loop
        speed_frame = tk.Frame(self, bg="black")
        speed_frame.pack(pady=3)

        tk.Label(speed_frame, text="Speed:", fg="white", bg="black").grid(row=0, column=0, padx=5)
        self.speed_var = tk.StringVar(value="1.0x")
        speed_options = ["0.1x", "0.25x", "0.5x", "1.0x", "1.5x", "2.0x", "5.0x", "10.0x"]
        tk.OptionMenu(speed_frame, self.speed_var, *speed_options).grid(row=0, column=1, padx=5)

        tk.Label(speed_frame, text="Loop:", fg="white", bg="black").grid(row=0, column=2, padx=5)
        self.loop_var = tk.StringVar(value="1")
        loop_options = ["1", "2", "5", "10", "50", "100", "500", "1000", "∞ Infinite"]
        tk.OptionMenu(speed_frame, self.loop_var, *loop_options).grid(row=0, column=3, padx=5)

        # Buttons
        btn_frame = tk.Frame(self, bg="black")
        btn_frame.pack(pady=5)

        self.record_button = tk.Button(btn_frame, text="⏺ Record", width=12, command=self.toggle_recording)
        self.record_button.grid(row=0, column=0, padx=5)

        self.play_button = tk.Button(btn_frame, text="▶ Play", width=12, command=self.start_playback)
        self.play_button.grid(row=0, column=1, padx=5)

        self.delete_button = tk.Button(btn_frame, text="🗑 Delete", width=12, command=self.delete_selected)
        self.delete_button.grid(row=0, column=2, padx=5)

        self.rename_button = tk.Button(btn_frame, text="✏ Rename", width=12, command=self.rename_selected)
        self.rename_button.grid(row=0, column=3, padx=5)

        # Macro list
        tk.Label(self, text="Recorded Macros:", fg="white", bg="black").pack()
        self.listbox = tk.Listbox(self, width=50, height=10)
        self.listbox.pack(pady=5)

        self.refresh_macro_list()

        # Advanced panel
        self.adv_frame = tk.Frame(self, bg="gray15", bd=1, relief="ridge")
        self.adv_frame.pack(fill="x", pady=5)

        self.adv_open = False
        self.adv_toggle_btn = tk.Button(self.adv_frame, text="Advanced Settings ▼",
                                        command=self.toggle_advanced,
                                        bg="gray20", fg="white", relief="flat")
        self.adv_toggle_btn.pack(fill="x")

        self.adv_inner = tk.Frame(self.adv_frame, bg="gray15")

        # Hotkeys section
        hotkey_label = tk.Label(self.adv_inner, text="Hotkeys", fg="white", bg="gray15")
        hotkey_label.pack(pady=(5, 0))

        sep1 = tk.Frame(self.adv_inner, bg="gray30", height=1)
        sep1.pack(fill="x", padx=5, pady=2)

        hk_frame = tk.Frame(self.adv_inner, bg="gray15")
        hk_frame.pack(pady=5)

        tk.Label(hk_frame, text="Record Hotkey:", fg="white", bg="gray15").grid(row=0, column=0, padx=5, sticky="e")
        self.record_hotkey_label = tk.Label(hk_frame, text=self.record_hotkey or "None", fg="cyan", bg="gray15")
        self.record_hotkey_label.grid(row=0, column=1, padx=5, sticky="w")
        tk.Button(hk_frame, text="Set", command=self.set_record_hotkey).grid(row=0, column=2, padx=5)

        tk.Label(hk_frame, text="Playback Hotkey:", fg="white", bg="gray15").grid(row=1, column=0, padx=5, sticky="e")
        self.play_hotkey_label = tk.Label(hk_frame, text=self.play_hotkey or "None", fg="cyan", bg="gray15")
        self.play_hotkey_label.grid(row=1, column=1, padx=5, sticky="w")
        tk.Button(hk_frame, text="Set", command=self.set_play_hotkey).grid(row=1, column=2, padx=5)

        sep2 = tk.Frame(self.adv_inner, bg="gray30", height=1)
        sep2.pack(fill="x", padx=5, pady=2)

        # Recording mode
        mode_label = tk.Label(self.adv_inner, text="Recording Mode", fg="white", bg="gray15")
        mode_label.pack(pady=(5, 0))

        sep3 = tk.Frame(self.adv_inner, bg="gray30", height=1)
        sep3.pack(fill="x", padx=5, pady=2)

        mode_frame = tk.Frame(self.adv_inner, bg="gray15")
        mode_frame.pack(pady=5)

        tk.Radiobutton(mode_frame, text="Relative Movement", variable=self.record_mode, value="relative",
                       fg="white", bg="gray15", selectcolor="gray25").grid(row=0, column=0, padx=5)

        tk.Radiobutton(mode_frame, text="Exact Coordinates", variable=self.record_mode, value="absolute",
                       fg="white", bg="gray15", selectcolor="gray25").grid(row=0, column=1, padx=5)

        sep4 = tk.Frame(self.adv_inner, bg="gray30", height=1)
        sep4.pack(fill="x", padx=5, pady=2)

        tk.Label(self.adv_inner,
                 text="• Hotkeys are global\n• Saved to hotkeys.cfg\n• Not recorded into macros\n• Recording mode affects new recordings only",
                 fg="white", bg="gray15", justify="left").pack(pady=5)

        # Global listeners
        self.global_listener = pynput.keyboard.Listener(
            on_press=self.global_on_key_press,
            on_release=self.global_on_key_release)
        self.global_mouse_listener = pynput.mouse.Listener(
            on_click=self.global_on_click)

        self.global_listener.start()
        self.global_mouse_listener.start()

        # Hotkey assignment state
        self.assigning_record_hotkey = False
        self.assigning_play_hotkey = False

    # -------------------------
    # Advanced panel
    # -------------------------
    def toggle_advanced(self):
        self.adv_open = not self.adv_open
        if self.adv_open:
            self.adv_inner.pack(fill="x", padx=5, pady=5)
            self.adv_toggle_btn.config(text="Advanced Settings ▲")
        else:
            self.adv_inner.forget()
            self.adv_toggle_btn.config(text="Advanced Settings ▼")

    # -------------------------
    # Macro list
    # -------------------------
    def refresh_macro_list(self):
        self.listbox.delete(0, tk.END)
        files = sorted(glob.glob(os.path.join(self.macro_folder, "*.X")))
        for f in files:
            self.listbox.insert(tk.END, os.path.basename(f))

    def delete_selected(self):
        sel = self.listbox.curselection()
        if not sel:
            return
        filename = self.listbox.get(sel[0])
        path = os.path.join(self.macro_folder, filename)
        if os.path.exists(path):
            os.remove(path)
        self.refresh_macro_list()

    def rename_selected(self):
        sel = self.listbox.curselection()
        if not sel:
            return

        old_name = self.listbox.get(sel[0])
        old_path = os.path.join(self.macro_folder, old_name)

        new_name = simpledialog.askstring("Rename Macro", "Enter new name (without extension):", parent=self)
        if not new_name:
            return

        invalid_chars = '\\/:*?"<>|'
        for ch in invalid_chars:
            new_name = new_name.replace(ch, "_")

        new_name = new_name.strip()
        if not new_name:
            messagebox.showerror("Error", "Invalid name.")
            return

        if not new_name.lower().endswith(".x"):
            new_name += ".X"

        new_path = os.path.join(self.macro_folder, new_name)
        if os.path.exists(new_path):
            messagebox.showerror("Error", "A macro with that name already exists.")
            return

        os.rename(old_path, new_path)
        self.refresh_macro_list()

        for i in range(self.listbox.size()):
            if self.listbox.get(i) == new_name:
                self.listbox.selection_set(i)
                break

    # -------------------------
    # Recording
    # -------------------------
    def toggle_recording(self):
        if self.playing_back:
            return

        self.recording = not self.recording

        if self.recording:
            self.events = []
            self.start_time = time.time()
            self.record_button.config(text="⏹ Stop")

            self.last_x = None
            self.last_y = None

            self.key_listener = KeyListener(on_press=self.on_key_press, on_release=self.on_key_release)
            self.mouse_listener = MouseListener(on_click=self.on_click, on_scroll=self.on_scroll, on_move=self.on_move)

            self.key_listener.start()
            self.mouse_listener.start()

        else:
            self.record_button.config(text="⏺ Record")

            self.key_listener.stop()
            self.mouse_listener.stop()

            count = len(glob.glob(os.path.join(self.macro_folder, "*.X"))) + 1
            filename = f"macro_{count:03d}.X"

            with open(os.path.join(self.macro_folder, filename), "w") as f:
                for e in self.events:
                    f.write(e + "\n")

            self.refresh_macro_list()

    def record_event(self, etype, data):
        if not self.recording:
            return
        t = time.time() - self.start_time
        self.events.append(f"TIME={t:.4f} TYPE={etype} DATA={data}")

    # Keyboard events
    def on_key_press(self, key):
        if self.is_hotkey_key(key):
            return
        try:
            self.record_event("KEY_DOWN", key.char)
        except:
            self.record_event("KEY_DOWN", str(key))

    def on_key_release(self, key):
        if self.is_hotkey_key(key):
            return
        try:
            self.record_event("KEY_UP", key.char)
        except:
            self.record_event("KEY_UP", str(key))

    # Mouse events
    def on_click(self, x, y, button, pressed):
        if self.is_hotkey_mouse(button):
            return
        btn = "left" if button == Button.left else "right"
        self.record_event("MOUSE_CLICK", f"{btn}:{pressed}")

    def on_scroll(self, x, y, dx, dy):
        self.record_event("MOUSE_SCROLL", f"{dy}")

    def on_move(self, x, y):
        mode = self.record_mode.get()
        if mode == "relative":
            if self.last_x is None:
                self.last_x = x
                self.last_y = y
                return
            dx = x - self.last_x
            dy = y - self.last_y
            self.last_x = x
            self.last_y = y
            self.record_event("MOUSE_MOVE", f"{dx}:{dy}")
        else:
            self.record_event("MOUSE_MOVE_ABS", f"{x}:{y}")

    # -------------------------
    # Playback
    # -------------------------
    def start_playback(self):
        if self.recording or self.playing_back:
            return

        sel = self.listbox.curselection()
        if not sel:
            return

        filename = self.listbox.get(sel[0])
        self.current_macro = os.path.join(self.macro_folder, filename)

        self.playback_speed = float(self.speed_var.get().replace("x", ""))

        if self.loop_var.get() == "∞ Infinite":
            self.loop_infinite = True
            self.loop_count = 1
        else:
            self.loop_infinite = False
            self.loop_count = int(self.loop_var.get())

        self.playing_back = True
        self.play_button.config(text="⏸ Playing")

        threading.Thread(target=self.playback_thread, daemon=True).start()

    def stop_playback(self):
        self.playing_back = False

    def playback_thread(self):
        events = []

        with open(self.current_macro, "r") as f:
            for line in f:
                line = line.strip()
                if not line.startswith("TIME="):
                    continue
                parts = line.split()
                t = float(parts[0].split("=")[1])
                etype = parts[1].split("=")[1]
                data = parts[2].split("=")[1]
                events.append((t, etype, data))

        loops_done = 0

        while self.playing_back:
            loops_done += 1
            start = time.time()
            idx = 0

            while idx < len(events) and self.playing_back:
                now = (time.time() - start) * self.playback_speed
                t, etype, data = events[idx]

                if now >= t:
                    self.apply_event(etype, data)
                    idx += 1
                else:
                    time.sleep(0.0005)

            if not self.loop_infinite and loops_done >= self.loop_count:
                break

        self.playing_back = False
        self.play_button.config(text="▶ Play")

    def apply_event(self, etype, data):
        if etype == "KEY_DOWN":
            self.keyboard.press(self.parse_key(data))

        elif etype == "KEY_UP":
            self.keyboard.release(self.parse_key(data))

        elif etype == "MOUSE_MOVE":
            dx, dy = map(int, data.split(":"))
            send_mouse_move(dx, dy)

        elif etype == "MOUSE_MOVE_ABS":
            x, y = map(int, data.split(":"))
            send_mouse_move_absolute(x, y)

        elif etype == "MOUSE_CLICK":
            btn, pressed = data.split(":")
            send_mouse_click(btn, pressed == "True")

        elif etype == "MOUSE_SCROLL":
            send_mouse_scroll(int(data))

    def parse_key(self, k):
        try:
            if len(k) == 1:
                return k
            return getattr(Key, k.replace("Key.", ""))
        except:
            return k

    # -------------------------
    # Hotkeys: config
    # -------------------------
    def load_hotkeys(self):
        config = configparser.ConfigParser()
        if os.path.exists(self.config_file):
            config.read(self.config_file)
            self.record_hotkey = config.get("hotkeys", "record", fallback=None)
            self.play_hotkey = config.get("hotkeys", "play", fallback=None)
        else:
            self.record_hotkey = None
            self.play_hotkey = None

    def save_hotkeys(self):
        config = configparser.ConfigParser()
        config["hotkeys"] = {}
        config["hotkeys"]["record"] = self.record_hotkey or ""
        config["hotkeys"]["play"] = self.play_hotkey or ""
        with open(self.config_file, "w") as f:
            config.write(f)

    # -------------------------
    # Hotkeys: assignment
    # -------------------------
    def set_record_hotkey(self):
        self.assigning_record_hotkey = True
        self.assigning_play_hotkey = False
        self.record_hotkey_label.config(text="Press any key or mouse...")

    def set_play_hotkey(self):
        self.assigning_play_hotkey = True
        self.assigning_record_hotkey = False
        self.play_hotkey_label.config(text="Press any key or mouse...")

    def finalize_hotkey(self, hotkey_str):
        if self.assigning_record_hotkey:
            if hotkey_str == self.play_hotkey:
                messagebox.showerror("Error", "Record hotkey cannot match playback hotkey.")
                self.record_hotkey_label.config(text=self.record_hotkey or "None")
            else:
                self.record_hotkey = hotkey_str
                self.record_hotkey_label.config(text=self.record_hotkey)

        elif self.assigning_play_hotkey:
            if hotkey_str == self.record_hotkey:
                messagebox.showerror("Error", "Playback hotkey cannot match record hotkey.")
                self.play_hotkey_label.config(text=self.play_hotkey or "None")
            else:
                self.play_hotkey = hotkey_str
                self.play_hotkey_label.config(text=self.play_hotkey)

        self.assigning_record_hotkey = False
        self.assigning_play_hotkey = False
        self.save_hotkeys()

    # -------------------------
    # Hotkeys: global listener
    # -------------------------
    def global_on_key_press(self, key):
        if key in (Key.ctrl_l, Key.ctrl_r):
            self.mod_ctrl = True
        if key in (Key.shift, Key.shift_l, Key.shift_r):
            self.mod_shift = True
        if key in (Key.alt_l, Key.alt_r):
            self.mod_alt = True

        hotkey_str = self.build_hotkey_string_from_key(key)

        if self.assigning_record_hotkey or self.assigning_play_hotkey:
            self.finalize_hotkey(hotkey_str)
            return

        if hotkey_str == self.record_hotkey:
            self.toggle_recording()
        elif hotkey_str == self.play_hotkey:
            if self.playing_back:
                self.stop_playback()
            else:
                self.start_playback()

    def global_on_key_release(self, key):
        if key in (Key.ctrl_l, Key.ctrl_r):
            self.mod_ctrl = False
        if key in (Key.shift, Key.shift_l, Key.shift_r):
            self.mod_shift = False
        if key in (Key.alt_l, Key.alt_r):
            self.mod_alt = False

    def global_on_click(self, x, y, button, pressed):
        if not pressed:
            return

        hotkey_str = self.build_hotkey_string_from_mouse(button)

        if self.assigning_record_hotkey or self.assigning_play_hotkey:
            self.finalize_hotkey(hotkey_str)
            return

        if hotkey_str == self.record_hotkey:
            self.toggle_recording()
        elif hotkey_str == self.play_hotkey:
            if self.playing_back:
                self.stop_playback()
            else:
                self.start_playback()

    # -------------------------
    # Hotkeys: helpers
    # -------------------------
    def build_hotkey_string_from_key(self, key):
        parts = []
        if self.mod_ctrl:
            parts.append("Ctrl")
        if self.mod_shift:
            parts.append("Shift")
        if self.mod_alt:
            parts.append("Alt")

        try:
            if hasattr(key, "char") and key.char is not None:
                base = key.char.upper()
            else:
                base = str(key).replace("Key.", "").upper()
        except:
            base = str(key)

        parts.append(base)
        return "+".join(parts)

    def build_hotkey_string_from_mouse(self, button):
        parts = []
        if self.mod_ctrl:
            parts.append("Ctrl")
        if self.mod_shift:
            parts.append("Shift")
        if self.mod_alt:
            parts.append("Alt")

        if button == Button.left:
            base = "MouseLeft"
        elif button == Button.right:
            base = "MouseRight"
        elif button == Button.middle:
            base = "MouseMiddle"
        elif button == Button.x1:
            base = "MouseButton4"
        elif button == Button.x2:
            base = "MouseButton5"
        else:
            base = "MouseUnknown"

        parts.append(base)
        return "+".join(parts)

    def is_hotkey_key(self, key):
        hotkey_str = self.build_hotkey_string_from_key(key)
        return hotkey_str == self.record_hotkey or hotkey_str == self.play_hotkey

    def is_hotkey_mouse(self, button):
        hotkey_str = self.build_hotkey_string_from_mouse(button)
        return hotkey_str == self.record_hotkey or hotkey_str == self.play_hotkey


# -------------------------
# Standalone run
# -------------------------
if __name__ == "__main__":
    root = tk.Tk()
    root.title("Macro Recorder")
    app = MacroRecorder(root)
    app.pack(fill="both", expand=True)
    root.mainloop()
