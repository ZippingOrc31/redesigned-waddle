@echo off
:: --- Elevate to Administrator ---
:: Check if admin
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting admin privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: --- CONFIG ---
:: If Python isn't on PATH, set full path here:
:: set PYTHON=C:\Path\To\python.exe
set PYTHON=python

:: Hard‑code your script path here:
set SCRIPT=C:\Users\dmcge\Downloads\Suite\main.pyw

echo Running %SCRIPT% as Administrator...
"%PYTHON%" "%SCRIPT%"
