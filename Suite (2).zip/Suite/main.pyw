import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox
import json

from rapdi import MacroRecorder
from controllerclicker import ControllerClicker
from mouseclicker import MouseClicker


def main():
    global controller_instance, mouse_instance

    root = tk.Tk()

    # Borderless, topmost, semi-transparent
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    root.attributes("-alpha", 0.92)
    root.configure(bg="#d0d0d0")

    # -------------------------
    # THEME APPLY FUNCTION
    # -------------------------
    def apply_theme(colors):
        # Background
        root.configure(bg=colors["background"])
        main_frame.configure(bg=colors["background"])
        tools_frame.configure(bg=colors["background"])
        macro_panel.configure(bg=colors["background"])

        # Top bar
        top_bar.configure(bg=colors["topbar"])
        file_button.configure(bg=colors["topbar"], fg=colors["text"])
        exit_btn.configure(bg=colors["topbar"], fg=colors["text"])

        # Accent (resize handle)
        resize_handle.configure(bg=colors["accent"])

    # -------------------------
    # COLOR CUSTOMIZER WINDOW
    # -------------------------
    def open_color_customizer():
        win = tk.Toplevel(root)
        win.title("Color Customizer")
        win.geometry("350x450")
        win.configure(bg="#222222")

        selected_colors = {
            "background": root["bg"],
            "topbar": top_bar["bg"],
            "text": file_button["fg"],
            "accent": resize_handle["bg"]
        }

        tk.Label(win, text="Color Customizer", fg="white", bg="#222222",
                 font=("Arial", 14, "bold")).pack(pady=10)

        # ---- Color Picker Builder ----
        def make_color_picker(label, key):
            frame = tk.Frame(win, bg="#222222")
            frame.pack(pady=5)
            tk.Label(frame, text=label, fg="white", bg="#222222").pack(side="left", padx=10)
            tk.Button(frame, text="Pick",
                      command=lambda k=key: pick_color(k)).pack(side="left")

        def pick_color(key):
            color = colorchooser.askcolor()[1]
            if color:
                selected_colors[key] = color

        make_color_picker("Background Color", "background")
        make_color_picker("Top Bar Color", "topbar")
        make_color_picker("Text Color", "text")
        make_color_picker("Accent / Resize Handle", "accent")

        # ---- Presets ----
        tk.Label(win, text="Presets", fg="white", bg="#222222",
                 font=("Arial", 12, "bold")).pack(pady=10)

        preset_frame = tk.Frame(win, bg="#222222")
        preset_frame.pack()

        presets = {
            "Dark": {"background": "#1e1e1e", "topbar": "#2a2a2a", "text": "#ffffff", "accent": "#444444"},
            "Neon": {"background": "#0f0f0f", "topbar": "#1a1a1a", "text": "#00ffea", "accent": "#ff00c8"},
            "Pastel": {"background": "#f2e9e4", "topbar": "#c9ada7", "text": "#222222", "accent": "#9a8c98"},
            "Cyber": {"background": "#0a0f0d", "topbar": "#0f1c1b", "text": "#00ff9f", "accent": "#00b3ff"}
        }

        def apply_preset(colors):
            selected_colors.update(colors)
            apply_theme(selected_colors)

        for name, colors in presets.items():
            tk.Button(
                preset_frame,
                text=name,
                width=12,
                command=lambda c=colors: apply_preset(c)
            ).pack(pady=3)

        # ---- Apply / Save / Load ----
        tk.Button(win, text="Apply Theme", width=20,
                  command=lambda: apply_theme(selected_colors)).pack(pady=10)

        def save_theme():
            path = filedialog.asksaveasfilename(
                defaultextension=".theme",
                filetypes=[("Theme Files", "*.theme")]
            )
            if not path:
                return
            with open(path, "w") as f:
                json.dump(selected_colors, f)
            messagebox.showinfo("Saved", "Theme saved successfully!")

        def load_theme():
            path = filedialog.askopenfilename(
                filetypes=[("Theme Files", "*.theme")]
            )
            if not path:
                return
            try:
                with open(path, "r") as f:
                    data = json.load(f)
                selected_colors.update(data)
                apply_theme(selected_colors)
            except:
                messagebox.showerror("Error", "Invalid theme file.")

        tk.Button(win, text="Save Theme", width=20, command=save_theme).pack(pady=5)
        tk.Button(win, text="Load Theme", width=20, command=load_theme).pack(pady=5)

    # -------------------------
    # TOP BAR (drag + menu + exit)
    # -------------------------
    top_bar = tk.Frame(root, bg="#c0c0c0", height=30)
    top_bar.pack(fill="x")

    def start_drag(event):
        root._drag_start_x = event.x
        root._drag_start_y = event.y

    def do_drag(event):
        x = root.winfo_x() + event.x - root._drag_start_x
        y = root.winfo_y() + event.y - root._drag_start_y
        root.geometry(f"+{x}+{y}")

    top_bar.bind("<ButtonPress-1>", start_drag)
    top_bar.bind("<B1-Motion>", do_drag)

    # File menu popup
    file_menu = tk.Menu(root, tearoff=0)
    file_menu.add_command(label="Color Customize", command=open_color_customizer)
    file_menu.add_separator()
    file_menu.add_command(label="Exit", command=root.destroy)

    def open_file_menu(event=None):
        x = file_button.winfo_rootx()
        y = file_button.winfo_rooty() + file_button.winfo_height()
        file_menu.tk_popup(x, y)

    file_button = tk.Button(top_bar, text="File ▼", bg="#c0c0c0", relief="flat", command=open_file_menu)
    file_button.pack(side="left", padx=5)

    exit_btn = tk.Button(top_bar, text="❌", bg="#c0c0c0", fg="black",
                         relief="flat", command=root.destroy)
    exit_btn.pack(side="right", padx=5)

    # -------------------------
    # MAIN CONTENT AREA
    # -------------------------
    main_frame = tk.Frame(root, bg="#d0d0d0")
    main_frame.pack(fill="both", expand=True)

    macro_panel = MacroRecorder(main_frame)
    macro_panel.pack(side="left", padx=10, pady=10)

    tools_frame = tk.Frame(main_frame, bg="#d0d0d0")
    tools_frame.pack(side="left", padx=10, pady=10)

    # -------------------------
    # TOOL TOGGLE SYSTEM
    # -------------------------
    controller_instance = None
    mouse_instance = None

    def toggle_controller():
        global controller_instance
        if controller_instance is None:
            controller_instance = ControllerClicker(tools_frame)
            controller_instance.pack(pady=10)
        else:
            try:
                controller_instance.stop_thread()
            except Exception:
                pass
            controller_instance.destroy()
            controller_instance = None

    def toggle_mouse():
        global mouse_instance
        if mouse_instance is None:
            mouse_instance = MouseClicker(tools_frame)
            mouse_instance.pack(pady=10)
        else:
            try:
                mouse_instance.stop_thread()
            except Exception:
                pass
            mouse_instance.destroy()
            mouse_instance = None

    tk.Button(tools_frame, text="Controller Clicker", width=20,
              command=toggle_controller).pack(pady=5)

    tk.Button(tools_frame, text="Mouse Clicker", width=20,
              command=toggle_mouse).pack(pady=5)

    # -------------------------
    # RESIZE HANDLE
    # -------------------------
    resize_handle = tk.Frame(root, bg="#909090", cursor="size_nw_se", height=12, width=12)
    resize_handle.place(relx=1.0, rely=1.0, anchor="se")

    def start_resize(event):
        root._resize_start_x = event.x
        root._resize_start_y = event.y
        root._start_width = root.winfo_width()
        root._start_height = root.winfo_height()

    def do_resize(event):
        dx = event.x - root._resize_start_x
        dy = event.y - root._resize_start_y
        new_w = max(300, root._start_width + dx)
        new_h = max(200, root._start_height + dy)
        root.geometry(f"{new_w}x{new_h}")

    resize_handle.bind("<ButtonPress-1>", start_resize)
    resize_handle.bind("<B1-Motion>", do_resize)

    root.mainloop()


if __name__ == "__main__":
    main()
